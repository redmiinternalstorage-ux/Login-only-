<html>
<body>
<form  method="POST">
 Username: <input type="text" name="username">
  Password: <input type="password" name="password">
<button>submit</button>
</form>
</body>
</html>
<?php
require("cone.php");
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$a=$_POST["username"];
$b=$_POST["password"];

$sql="INSERT INTO `adminpage` (`username`, `password`) VALUES ('$a', '$b')";
if (mysqli_query($con,$sql))
{
 echo "record is inserted";
 }
 else{
   echo "Record is not inserted ";
   }
   }
  ?>