<?php
// ====== PHP SECTION (Runs before HTML) ======
$host = "localhost";     
$user = "root";          
$pass = "";              
$dbname = "liquorstore"; // ✅ Your database name

// Create connection
$con = mysqli_connect($host, $user, $pass, $dbname);

// Check connection
if (!$con) {
    die("❌ Database connection failed: " . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // ✅ Insert form data into checkout table
INSERT INTO `checkout` (`first_name`, `last_name`, `country_name`, `Street_Address`, `Town _City`, `Phone`, `email`) VALUES ('r', 're', 'erh', 'hrs', 'sr', '3', 'a@gmail.com');
    if (mysqli_query($con, $sql)) {
        echo "<script>alert('✅ Checkout details saved successfully!');</script>";
    } else {
        echo "<script>alert('⚠️ Database Error: " . mysqli_error($con) . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('images/bg_2.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .checkout-container {
            background: white;
            padding: 30px;
            border-radius:10px;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.15);
            width: 400px;
            text-align: center;
        }
        .checkout-container h2 { 
            margin-bottom: 20px; 
            color: #333; 
        }
        .checkout-container input[type="text"],
        .checkout-container input[type="email"],
        .checkout-container textarea {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            outline: none;
        }
        .checkout-container input:focus,
        .checkout-container textarea:focus { 
            border-color: #4a90e2; 
        }
        .checkout-container button {
            width: 100%;
            padding: 10px;
            background: #4a90e2;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        .checkout-container button:hover { 
            background: #357ab7; 
        }
    </style>
</head>
<body>
    <div class="checkout-container">
        <h2>Checkout Form</h2>
        <form method="post">
            <input type="text" name="fullname" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="text" name="subject" placeholder="Subject" required>
            <textarea name="message" placeholder="Message" rows="4" required></textarea>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
