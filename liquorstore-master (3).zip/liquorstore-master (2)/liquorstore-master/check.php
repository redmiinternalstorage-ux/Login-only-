<?php
require("cone.php"); // your database connection

// Only run this code if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Safely get the POST values
    $first_name     = $_POST["first_name"] ?? '';
    $last_name      = $_POST["last_name"] ?? '';
    $country_name   = $_POST["country_name"] ?? '';
    $Street_Address = $_POST["Street_Address"] ?? '';
    $Town_City      = $_POST["Town_City"] ?? '';
    $Phone          = $_POST["Phone"] ?? '';
    $mail           = $_POST["mail"] ?? '';

    $sql = "INSERT INTO checkout 
            $sql = "INSERT INTO checkout"
        (first_name, last_name, country_name, Street_Address, Town_City, Phone, mail)
        VALUES ('$first_name', '$last_name', '$country_name', '$Street_Address', '$Town_City', '$Phone', '$mail')";
first_name, last_name, country_name, Street_Address, Town_City, Phone, mail)

    if (mysqli_query($con, $sql)) {
        echo "<p style='color:green;'>✅ Record inserted successfully!</p>";
    } else {
        echo "<p style='color:red;'>❌ Record not inserted: " . mysqli_error($con) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout Form</title>
</head>
<body>
    <h2>Checkout Form</h2>
    <form method="POST" action="">
        First Name: <input type="text" name="first_name" required><br><br>
        Last Name: <input type="text" name="last_name" required><br><br>
        Country Name: <input type="text" name="country_name" required><br><br>
        Street Address: <input type="text" name="Street_Address" required><br><br>
        City: <input type="text" name="Town_City" required><br><br>
        Phone: <input type="text" name="Phone" required><br><br>
        Email: <input type="email" name="mail" required><br><br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
