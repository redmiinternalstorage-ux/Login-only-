<?php
$con=mysqli_connect("localhost","root","","liquorstore");
if(!$con)
{
die("connection failed".
mysqli_connect_error());
}
else
 echo"connection sucessfully";
 
?>