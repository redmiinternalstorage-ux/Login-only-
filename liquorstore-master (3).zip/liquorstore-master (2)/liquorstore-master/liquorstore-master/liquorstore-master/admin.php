<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: adminform.php");
    exit();
}

$dataFile = __DIR__ . '/data/products.json';
$products = [];
if (file_exists($dataFile)) {
    $json = file_get_contents($dataFile);
    $decoded = json_decode($json, true);
    if (is_array($decoded)) {
        $products = $decoded;
    }
}

$flash = $_SESSION['admin_flash'] ?? '';
unset($_SESSION['admin_flash']);

// Database connection for orders/payments
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

$orders = [];
$feedbackEntries = [];
$conn_admin = new mysqli($servername, $username, $password, $dbname);
if (!$conn_admin->connect_error) {
    // Check if checkout table exists
    $checkout_check = $conn_admin->query("SHOW TABLES LIKE 'checkout'");
    if ($checkout_check && $checkout_check->num_rows > 0) {
        // Fetch all orders/payments from checkout table
        $orders_query = "SELECT * FROM checkout ORDER BY created_at DESC";
        $orders_result = $conn_admin->query($orders_query);
        if ($orders_result) {
            while ($row = $orders_result->fetch_assoc()) {
                $orders[] = $row;
            }
            $orders_result->free();
        }
    }

    // Fetch feedback entries if table exists
    $feedback_check = $conn_admin->query("SHOW TABLES LIKE 'feedback'");
    if ($feedback_check && $feedback_check->num_rows > 0) {
        $feedback_query = "SELECT * FROM feedback ORDER BY created_at DESC";
        $feedback_result = $conn_admin->query($feedback_query);
        if ($feedback_result) {
            while ($row = $feedback_result->fetch_assoc()) {
                $feedbackEntries[] = $row;
            }
            $feedback_result->free();
        }
    }

    $conn_admin->close();
}
?>
<html>
  <head>
  <meta charset="UTF-8">
  <title>Liquor Store - Admin Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Spectral:wght@400;500;700&display=swap" rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Bootstrap for basic styling -->
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <!-- Custom Style -->
  <style>
    /* Background Image */
    body {
      margin: 0;
      font-family: 'Spectral', serif;
      background-image: url('images/bg_1.jpg'); 
      background-position: center;
     
      color: white;
      min-height: 100vh;
    }

    h2 {
      color: white;
      margin-top: 40px;
    }

    main {
      background-color: rgba(0, 0, 0, 0.6);
      padding: 40px;
      border-radius: 8px;
      max-width: 1100px;
      margin: 40px auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 40px;
    }

    table th,
    table td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: center;
      background-color: rgba(255, 255, 255, 0.1);
    }

    table th {
      background-color: rgba(255, 255, 255, 0.2);
    }

    button {
      padding: 8px 16px;
      background-color: #ff9900;
      border: none;
      color: white;
      border-radius: 4px;
      cursor: pointer;
    }

    .add-product-form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 40px;
    }

    .add-product-form label {
      display: flex;
      flex-direction: column;
      font-size: 16px;
    }

    .add-product-form input {
      padding: 8px;
      margin-top: 5px;
    }

    .orders,
    .feedback {
      background-color: rgba(255, 255, 255, 0.1);
      padding: 20px;
      border-radius: 4px;
      overflow-x: auto;
    }

    .orders table,
    .feedback table {
      font-size: 14px;
    }

    .orders table th,
    .feedback table th {
      position: sticky;
      top: 0;
      background-color: rgba(255, 255, 255, 0.3) !important;
      z-index: 10;
    }

    .orders table tr:hover,
    .feedback table tr:hover {
      background-color: rgba(255, 255, 255, 0.15) !important;
    }

    .admin-header {
      background-color: rgba(0, 0, 0, 0.8);
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    .admin-header h1 {
      color: white;
      margin: 0;
      font-size: 28px;
    }

    .logout-btn {
      background-color: #dc3545;
      padding: 10px 20px;
      border-radius: 5px;
      text-decoration: none;
      color: white;
      font-weight: bold;
      transition: background-color 0.3s;
    }

    .logout-btn:hover {
      background-color: #c82333;
      color: white;
      text-decoration: none;
    }

    .admin-nav {
      display: flex;
      gap: 15px;
      justify-content: center;
      margin-bottom: 30px;
      flex-wrap: wrap;
    }

    .admin-nav a {
      padding: 10px 20px;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.1);
      color: white;
      text-decoration: none;
      font-weight: 600;
      transition: background 0.3s, color 0.3s;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .admin-nav a:hover,
    .admin-nav a:focus {
      background: #ff9900;
      color: #1a1a1a;
    }

    @media (max-width: 768px) {
      .add-product-form {
        grid-template-columns: 1fr;
      }

      table img {
        width: 100px;
      }
    }
  </style>
  <script>
    function editProduct(product) {
      document.getElementById('form-action').value = 'update';
      document.getElementById('form-id').value = product.id;
      document.getElementById('form-name').value = product.name || '';
      document.getElementById('form-category').value = product.category || '';
      document.getElementById('form-price').value = product.price || '';
      document.getElementById('form-image').value = product.image || '';
      document.getElementById('form-badge-style').value = product.badge_style || '';
      document.getElementById('form-badge-text').value = product.badge_text || '';
      document.getElementById('form-featured').value = product.is_featured ? '1' : '0';
      document.getElementById('form-description').value = product.description || '';
      document.getElementById('form-submit-btn').textContent = 'Update Product';
      document.getElementById('add-product-section').textContent = 'Edit Product';
      
      // Scroll to form
      document.getElementById('add-product-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    
    function resetForm() {
      document.getElementById('form-action').value = 'add';
      document.getElementById('form-id').value = '';
      document.getElementById('product-form').reset();
      document.getElementById('form-submit-btn').textContent = 'Add Product';
      document.getElementById('add-product-section').textContent = 'Add New Product';
    }
  </script>
</head>
<body>
    <div class="admin-header">
        <h1>Admin Panel - Manage Products</h1>
        <a href="admin_logout.php" class="logout-btn">Logout</a>
    </div>
    <div class="admin-nav">
        <a href="#manage-products">Manage Items</a>
        <a href="#payment-orders">User Payments</a>
        <a href="#feedback-section">User Feedback</a>
    </div>
    <main>
        <h2 id="manage-products">Manage Products</h2>

        <?php if ($flash): ?>
            <div style="padding:12px 16px;margin-bottom:20px;border-radius:4px;background:#d4edda;color:#155724;">
                <?php echo htmlspecialchars($flash); ?>
            </div>
        <?php endif; ?>

        <table>
            <tr>
                <th>Image</th>
                <th>Name / Category</th>
                <th>Price</th>
                <th>Featured</th>
                <th>Actions</th>
            </tr>
            <?php if (empty($products)): ?>
                <tr>
                    <td colspan="5">No products found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" width="120"></td>
                        <td>
                            <strong><?php echo htmlspecialchars($product['name']); ?></strong><br>
                            <small><?php echo htmlspecialchars($product['category']); ?></small>
                            <?php if (!empty($product['badge_text'])): ?>
                                <div><span class="badge badge-<?php echo htmlspecialchars($product['badge_style'] ?: 'primary'); ?>"><?php echo htmlspecialchars($product['badge_text']); ?></span></div>
                            <?php endif; ?>
                            <?php if (!empty($product['description'])): ?>
                                <div style="font-size:12px;margin-top:6px;"><?php echo htmlspecialchars($product['description']); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>$<?php echo number_format($product['price'], 2); ?></td>
                        <td><?php echo !empty($product['is_featured']) ? 'Yes' : 'No'; ?></td>
                        <td>
                            <button type="button" onclick="editProduct(<?php echo htmlspecialchars(json_encode($product)); ?>)" style="margin-right: 5px; background-color: #28a745;">Update</button>
                            <form action="admin_items.php" method="POST" onsubmit="return confirm('Delete this product?');" style="display: inline;">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">
                                <button type="submit" style="background-color: #dc3545;">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </table>
        <h2 id="add-product-section">Add New Product</h2>
        <form class="add-product-form" id="product-form" action="admin_items.php" method="POST">
            <input type="hidden" name="action" value="add" id="form-action">
            <input type="hidden" name="id" id="form-id">
            <label>Name:<input type="text" name="name" id="form-name" required></label>
            <label>Category:<input type="text" name="category" id="form-category" placeholder="e.g. Whiskey"></label>
            <label>Price:<input type="number" name="price" id="form-price" step="0.01" min="0" required></label>
            <label>Image URL:<input type="text" name="image" id="form-image" placeholder="images/prod-1.jpg" required></label>
            <label>Badge Style:<input type="text" name="badge_style" id="form-badge-style" placeholder="sale / seller / new"></label>
            <label>Badge Text:<input type="text" name="badge_text" id="form-badge-text" placeholder="Sale"></label>
            <label>Featured:
                <select name="is_featured" id="form-featured">
                    <option value="0">No</option>
                    <option value="1">Yes</option>
                </select>
            </label>
            <label>Description:
                <textarea name="description" id="form-description" rows="3" style="min-height:80px;"></textarea>
            </label>
            <div style="grid-column: 1 / -1;">
                <button type="submit" id="form-submit-btn">Add Product</button>
                <button type="button" onclick="resetForm()" style="background-color: #6c757d; margin-left: 10px;">Cancel</button>
            </div>
        </form>
        <h2 id="payment-orders">Payment & Order Details</h2>
        <div class="orders">
            <?php if (empty($orders)): ?>
                <p>No orders/payments found yet.</p>
            <?php else: ?>
                <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                    <thead>
                        <tr style="background-color: rgba(255, 255, 255, 0.2);">
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Order ID</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Customer Name</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Email</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Phone</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Address</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Payment Method</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Payment Status</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Payment Ref</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: right;">Subtotal</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: right;">Delivery</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: right;">Discount</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: right;">Total</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): 
                            $payment_meta = !empty($order['payment_metadata']) ? json_decode($order['payment_metadata'], true) : [];
                            $full_address = $order['Street_Address'] . ', ' . $order['Town_City'] . ', ' . $order['country_name'];
                        ?>
                            <tr style="background-color: rgba(255, 255, 255, 0.1);">
                                <td style="padding: 10px; border: 1px solid #ddd;">#<?php echo htmlspecialchars($order['id']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($order['mail']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($order['Phone']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; max-width: 200px; word-wrap: break-word;"><?php echo htmlspecialchars($full_address); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;">
                                    <?php echo htmlspecialchars($order['payment_method']); ?>
                                    <?php if (!empty($payment_meta)): ?>
                                        <br><small style="font-size: 11px; color: #ccc;">
                                            <?php 
                                            if (isset($payment_meta['account_name'])) echo "Account: " . htmlspecialchars($payment_meta['account_name']) . "<br>";
                                            if (isset($payment_meta['reference'])) echo "Ref: " . htmlspecialchars($payment_meta['reference']) . "<br>";
                                            if (isset($payment_meta['paypal_email'])) echo "PayPal: " . htmlspecialchars($payment_meta['paypal_email']) . "<br>";
                                            if (isset($payment_meta['upi_id'])) echo "UPI: " . htmlspecialchars($payment_meta['upi_id']) . "<br>";
                                            if (isset($payment_meta['check_holder'])) echo "Check Holder: " . htmlspecialchars($payment_meta['check_holder']) . "<br>";
                                            if (isset($payment_meta['check_number'])) echo "Check #: " . htmlspecialchars($payment_meta['check_number']) . "<br>";
                                            ?>
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 10px; border: 1px solid #ddd;">
                                    <span style="padding: 4px 8px; border-radius: 3px; font-size: 12px; 
                                        background-color: <?php 
                                            echo $order['payment_status'] == 'Authorized' || $order['payment_status'] == 'Completed' ? '#28a745' : 
                                                ($order['payment_status'] == 'Failed' ? '#dc3545' : '#ffc107'); 
                                        ?>; 
                                        color: white;">
                                        <?php echo htmlspecialchars($order['payment_status']); ?>
                                    </span>
                                </td>
                                <td style="padding: 10px; border: 1px solid #ddd; font-size: 11px;"><?php echo htmlspecialchars($order['payment_reference'] ?? 'N/A'); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">$<?php echo number_format($order['subtotal'], 2); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">$<?php echo number_format($order['delivery'], 2); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">$<?php echo number_format($order['discount'], 2); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; text-align: right; font-weight: bold; color: #ff9900;">$<?php echo number_format($order['total'], 2); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; font-size: 11px;"><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background-color: rgba(255, 255, 255, 0.2); font-weight: bold;">
                            <td colspan="8" style="padding: 12px; border: 1px solid #ddd; text-align: right;">Total Orders: <?php echo count($orders); ?></td>
                            <td colspan="4" style="padding: 12px; border: 1px solid #ddd; text-align: right;">
                                Grand Total: $<?php 
                                    $grand_total = array_sum(array_column($orders, 'total'));
                                    echo number_format($grand_total, 2); 
                                ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            <?php endif; ?>
        </div>
        <h2 id="feedback-section">User Feedback</h2>
        <div class="feedback">
            <?php if (empty($feedbackEntries)): ?>
                <p>No feedback entries available.</p>
            <?php else: ?>
                <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                    <thead>
                        <tr style="background-color: rgba(255, 255, 255, 0.2);">
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">ID</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Name</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Email</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Subject</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Message</th>
                            <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($feedbackEntries as $feedback): ?>
                            <tr style="background-color: rgba(255, 255, 255, 0.1);">
                                <td style="padding: 10px; border: 1px solid #ddd;">#<?php echo htmlspecialchars($feedback['id']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($feedback['full_name']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($feedback['email_address']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo htmlspecialchars($feedback['subject']); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; max-width: 250px; text-align: left; white-space: pre-wrap;"><?php echo nl2br(htmlspecialchars($feedback['message'])); ?></td>
                                <td style="padding: 10px; border: 1px solid #ddd; font-size: 12px;"><?php echo date('M d, Y H:i', strtotime($feedback['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>

