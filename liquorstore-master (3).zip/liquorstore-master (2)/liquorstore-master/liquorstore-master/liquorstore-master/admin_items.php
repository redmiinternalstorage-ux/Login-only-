<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(403);
    echo 'Unauthorized';
    exit;
}

$dataFile = __DIR__ . '/data/products.json';

function load_products($file)
{
    if (!file_exists($file)) {
        return [];
    }
    $json = file_get_contents($file);
    $decoded = json_decode($json, true);
    return is_array($decoded) ? $decoded : [];
}

function save_products($file, $products)
{
    $encoded = json_encode(array_values($products), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if (file_put_contents($file, $encoded) === false) {
        throw new RuntimeException('Failed to write products file');
    }
}

function slugify($value)
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/i', '-', $value);
    return trim($value, '-');
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    $products = load_products($dataFile);

    if ($method === 'POST' && $action === 'add') {
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
        $image = trim($_POST['image'] ?? '');
        $badge_style = trim($_POST['badge_style'] ?? '');
        $badge_text = trim($_POST['badge_text'] ?? '');
        $is_featured = isset($_POST['is_featured']) ? (bool)$_POST['is_featured'] : false;
        $description = trim($_POST['description'] ?? '');

        if ($name === '' || $price <= 0 || $image === '') {
            throw new RuntimeException('Name, positive price, and image URL are required.');
        }

        $id = slugify($name);
        $suffix = 1;
        $existingIds = array_column($products, 'id');
        $baseId = $id !== '' ? $id : ('item-' . time());
        while (in_array($id, $existingIds, true)) {
            $id = $baseId . '-' . $suffix++;
        }

        $products[] = [
            'id' => $id,
            'name' => $name,
            'category' => $category ?: 'General',
            'price' => round($price, 2),
            'image' => $image,
            'badge_style' => $badge_style,
            'badge_text' => $badge_text,
            'is_featured' => $is_featured,
            'description' => $description,
        ];

        save_products($dataFile, $products);
        save_products($dataFile, $products);
        $_SESSION['admin_flash'] = 'Product added successfully.';
        header('Location: admin.php');
        exit;
    }

    if ($method === 'POST' && $action === 'update') {
        $id = trim($_POST['id'] ?? '');
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
        $image = trim($_POST['image'] ?? '');
        $badge_style = trim($_POST['badge_style'] ?? '');
        $badge_text = trim($_POST['badge_text'] ?? '');
        $is_featured = isset($_POST['is_featured']) ? (bool)$_POST['is_featured'] : false;
        $description = trim($_POST['description'] ?? '');

        if ($id === '' || $name === '' || $price <= 0 || $image === '') {
            throw new RuntimeException('ID, name, positive price, and image URL are required.');
        }

        $found = false;
        foreach ($products as $key => $product) {
            if ($product['id'] === $id) {
                $products[$key] = [
                    'id' => $id,
                    'name' => $name,
                    'category' => $category ?: 'General',
                    'price' => round($price, 2),
                    'image' => $image,
                    'badge_style' => $badge_style,
                    'badge_text' => $badge_text,
                    'is_featured' => $is_featured,
                    'description' => $description,
                ];
                $found = true;
                break;
            }
        }

        if (!$found) {
            throw new RuntimeException('Product not found.');
        }

        save_products($dataFile, $products);
        $_SESSION['admin_flash'] = 'Product updated successfully.';
        header('Location: admin.php');
        exit;
    }

    if ($method === 'POST' && $action === 'delete') {
        $id = trim($_POST['id'] ?? '');
        if ($id === '') {
            throw new RuntimeException('Invalid product id');
        }

        $products = array_filter($products, function ($product) use ($id) {
            return $product['id'] !== $id;
        });

        save_products($dataFile, $products);
        $_SESSION['admin_flash'] = 'Product deleted.';
        header('Location: admin.php');
        exit;
    }

    if ($method === 'GET') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'data' => $products]);
        exit;
    }

    throw new RuntimeException('Unsupported request');
} catch (Exception $e) {
    if ($method === 'GET') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    } else {
        $_SESSION['admin_flash'] = $e->getMessage();
        header('Location: admin.php');
    }
}

