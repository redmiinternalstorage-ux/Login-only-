<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";   // default XAMPP username
$password = "";       // default XAMPP password
$dbname = "liquorstore";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    $_SESSION['login_error'] = "Database connection failed. Please contact administrator.";
    header("Location: adminform.php");
    exit();
}

// Select database
if (!$conn->select_db($dbname)) {
    // Database doesn't exist, try to create it
    $create_db_sql = "CREATE DATABASE IF NOT EXISTS " . $conn->real_escape_string($dbname);
    if ($conn->query($create_db_sql)) {
        $conn->select_db($dbname);
    } else {
        $_SESSION['login_error'] = "Database not found. Please run setup_database.php first.";
        $conn->close();
        header("Location: adminform.php");
        exit();
    }
}

// Check if form was submitted
if (!isset($_POST['username']) || !isset($_POST['password'])) {
    $_SESSION['login_error'] = "Please enter both username and password!";
    header("Location: adminform.php");
    exit();
}

// Get form values
$user = trim($_POST['username']);
$pass = trim($_POST['password']);

// Validate input
if (empty($user) || empty($pass)) {
    $_SESSION['login_error'] = "Username and password cannot be empty!";
    header("Location: adminform.php");
    exit();
}

// Check if adminpage table exists, create if it doesn't
$table_check = $conn->query("SHOW TABLES LIKE 'adminpage'");
if ($table_check->num_rows == 0) {
    // Create adminpage table if it doesn't exist
    $create_table_sql = "CREATE TABLE IF NOT EXISTS `adminpage` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(255) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    if (!$conn->query($create_table_sql)) {
        $_SESSION['login_error'] = "Database error: Could not create admin table.";
        $conn->close();
        header("Location: adminform.php");
        exit();
    }
    
    // Create default admin account (username: admin, password: admin)
    $default_admin = "admin";
    $default_password = "admin";
    $insert_admin_sql = "INSERT INTO adminpage (username, password) VALUES (?, ?)";
    $insert_stmt = $conn->prepare($insert_admin_sql);
    if ($insert_stmt) {
        $insert_stmt->bind_param("ss", $default_admin, $default_password);
        $insert_stmt->execute();
        $insert_stmt->close();
    }
} else {
    // Check if default admin exists, if not create it
    $check_admin = $conn->query("SELECT COUNT(*) as count FROM adminpage WHERE username = 'admin'");
    $row = $check_admin->fetch_assoc();
    if ($row['count'] == 0) {
        // Create default admin account
        $default_admin = "admin";
        $default_password = "admin";
        $insert_admin_sql = "INSERT INTO adminpage (username, password) VALUES (?, ?)";
        $insert_stmt = $conn->prepare($insert_admin_sql);
        if ($insert_stmt) {
            $insert_stmt->bind_param("ss", $default_admin, $default_password);
            $insert_stmt->execute();
            $insert_stmt->close();
        }
    } else {
        // Ensure admin password is correct (update if needed)
        $check_password = $conn->query("SELECT password FROM adminpage WHERE username = 'admin'");
        $pwd_row = $check_password->fetch_assoc();
        if ($pwd_row && $pwd_row['password'] != 'admin') {
            // Update password to 'admin'
            $update_sql = "UPDATE adminpage SET password = 'admin' WHERE username = 'admin'";
            $conn->query($update_sql);
        }
    }
}

// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("SELECT username, password FROM adminpage WHERE username = ? AND password = ?");

// Check if prepare was successful
if ($stmt === false) {
    $_SESSION['login_error'] = "Database error. Please try again later.";
    $conn->close();
    header("Location: adminform.php");
    exit();
}

// Bind parameters
$bind_result = $stmt->bind_param("ss", $user, $pass);

// Check if bind was successful
if ($bind_result === false) {
    $_SESSION['login_error'] = "Database error. Please try again later.";
    $stmt->close();
    $conn->close();
    header("Location: adminform.php");
    exit();
}

// Execute statement
$execute_result = $stmt->execute();

// Check if execute was successful
if ($execute_result === false) {
    $_SESSION['login_error'] = "Database error. Please try again later.";
    $stmt->close();
    $conn->close();
    header("Location: adminform.php");
    exit();
}

$result = $stmt->get_result();

// Check if credentials exist in database
if ($result->num_rows > 0) {
    // Valid credentials found in database
    // Store successful login attempt in database
    // First, try to create login_logs table if it doesn't exist
    $create_table_sql = "CREATE TABLE IF NOT EXISTS admin_login_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(20) DEFAULT 'success'
    )";
    $conn->query($create_table_sql);
    
    // Insert login log
    $login_log_sql = "INSERT INTO admin_login_logs (username, status) VALUES (?, 'success')";
    $log_stmt = $conn->prepare($login_log_sql);
    $log_stmt->bind_param("s", $user);
    $log_stmt->execute();
    $log_stmt->close();
    
    // Set session variables
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_username'] = $user;
    
    // Redirect to admin panel
    header("Location: admin.php");
    exit();
} else {
    // Invalid credentials - store failed login attempt
    $create_table_sql = "CREATE TABLE IF NOT EXISTS admin_login_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(20) DEFAULT 'failed'
    )";
    $conn->query($create_table_sql);
    
    // Insert failed login log
    $login_log_sql = "INSERT INTO admin_login_logs (username, status) VALUES (?, 'failed')";
    $log_stmt = $conn->prepare($login_log_sql);
    $log_stmt->bind_param("s", $user);
    $log_stmt->execute();
    $log_stmt->close();
    
    // Redirect back to login with error
    $_SESSION['login_error'] = "Invalid username or password! Please check your credentials.";
    header("Location: adminform.php");
    exit();
}

$stmt->close();
$conn->close();
?>
