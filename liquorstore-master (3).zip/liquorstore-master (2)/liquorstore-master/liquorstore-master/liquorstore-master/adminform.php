<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url('images/image_3.jpg'); 
      
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .login-container {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 4px 12px rgba(0,0,0,0.15);
      width: 320px;
      text-align: center;
    }
    .login-container h2 {
      margin-bottom: 20px;
      color: #333;
    }
    .login-container input[type="text"],
    .login-container input[type="password"] {
      width: 100%;
      padding: 10px;
      margin: 8px 0;
      border: 1px solid #ccc;
      border-radius: 6px;
      outline: none;
    }
    .login-container input[type="text"]:focus,
    .login-container input[type="password"]:focus {
      border-color: #4a90e2;
    }
    .login-container button {
      width: 100%;
      padding: 10px;
      background: #4a90e2;
      border: none;
      border-radius: 6px;
      color: white;
      font-size: 16px;
      cursor: pointer;
      margin-top: 10px;
    }
    .login-container button:hover {
      background: #357ab7;
    }
    .form-links {
      margin-top: 12px;
      text-align: right;
    }
    .form-links a {
      font-size: 13px;
      color: #4a90e2;
      text-decoration: none;
    }
    .form-links a:hover {
      text-decoration: underline;
    }
    .error-message {
      color: red;
      background: #ffe6e6;
      padding: 10px;
      border-radius: 5px;
      margin-bottom: 15px;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Admin Login</h2>
    <?php
    if (isset($_SESSION['login_error'])) {
        echo '<div class="error-message">' . htmlspecialchars($_SESSION['login_error']) . '</div>';
        unset($_SESSION['login_error']);
    }
    ?>
    <form id="loginForm" action="admin_login.php" method="post">
      <input type="text" id="userid" name="username" placeholder="Enter Username" required>
      <input type="password" id="password" name="password" placeholder="Enter Password" required>
      <button type="submit">SUBMIT</button>
    </form>
    <div class="form-links">
      <a href="#  ">Forgot Password?</a>
    </div>
  </div>

  
</body>
</html>

