<?php
// Database Verification Script
// This script checks if the database and tables are set up correctly

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

echo "<!DOCTYPE html>
<html>
<head>
    <title>Database Check</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; }
        .error { color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; }
        .info { color: blue; padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; }
        .warning { color: #856404; padding: 10px; background: #fff3cd; border: 1px solid #ffeaa7; margin: 10px 0; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .btn { display: inline-block; padding: 10px 20px; margin: 10px 5px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
        .btn:hover { background: #45a049; }
    </style>
</head>
<body>
<div class='container'>
<h1>Database Verification Report</h1>";

// Test 1: Check MySQL Connection
echo "<h2>1. MySQL Connection Test</h2>";
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    echo "<div class='error'>✗ Connection failed: " . $conn->connect_error . "</div>";
    echo "</div></body></html>";
    exit();
} else {
    echo "<div class='success'>✓ Successfully connected to MySQL server</div>";
}

// Test 2: Check Database Exists
echo "<h2>2. Database Check</h2>";
$result = $conn->query("SHOW DATABASES LIKE '$dbname'");
if ($result && $result->num_rows > 0) {
    echo "<div class='success'>✓ Database '$dbname' exists</div>";
    
    // Select database
    $conn->select_db($dbname);
} else {
    echo "<div class='error'>✗ Database '$dbname' does NOT exist</div>";
    echo "<div class='info'>Please run <a href='setup_database.php'>setup_database.php</a> to create it</div>";
    $conn->close();
    echo "</div></body></html>";
    exit();
}

// Test 3: Check Tables
echo "<h2>3. Tables Check</h2>";
$required_tables = ['users', 'feedback', 'adminpage', 'admin_login_logs'];
$tables_exist = true;

foreach ($required_tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        // Get record count
        $count_result = $conn->query("SELECT COUNT(*) as count FROM `$table`");
        $count_row = $count_result->fetch_assoc();
        $count = $count_row['count'];
        echo "<div class='success'>✓ Table '$table' exists ($count records)</div>";
    } else {
        echo "<div class='error'>✗ Table '$table' does NOT exist</div>";
        $tables_exist = false;
    }
}

if (!$tables_exist) {
    echo "<div class='warning'>⚠ Some tables are missing. Please run <a href='setup_database.php'>setup_database.php</a></div>";
}

// Test 4: Check Users Table Structure
echo "<h2>4. Users Table Structure</h2>";
$result = $conn->query("DESCRIBE `users`");
if ($result) {
    echo "<table>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='error'>✗ Could not describe users table</div>";
}

// Test 5: Show Recent Users
echo "<h2>5. Recent User Registrations</h2>";
$result = $conn->query("SELECT * FROM `users` ORDER BY `created_at` DESC LIMIT 10");
if ($result && $result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Mobile</th><th>Email</th><th>Age</th><th>State</th><th>Registered</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['your_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['mobile_no']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email_id']) . "</td>";
        echo "<td>" . $row['Age'] . "</td>";
        echo "<td>" . htmlspecialchars($row['State']) . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='warning'>⚠ No users found in database. Try registering a user.</div>";
}

// Test 6: Show Recent Feedback
echo "<h2>6. Recent Feedback</h2>";
$result = $conn->query("SELECT * FROM `feedback` ORDER BY `created_at` DESC LIMIT 10");
if ($result && $result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Date</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['full_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email_address']) . "</td>";
        echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
        echo "<td>" . htmlspecialchars(substr($row['message'], 0, 50)) . "...</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='info'>No feedback entries found</div>";
}

// Test 7: Test Insert Capability
echo "<h2>7. Insert Test</h2>";
$test_email = "test_" . time() . "@test.com";
$test_mobile = "999" . rand(1000000, 9999999);
$test_name = "Test User " . date('H:i:s');
$test_aadhar = "123456789012";
$test_age = 25;
$test_state = "Delhi";
$test_address = "Test Address";

$stmt = $conn->prepare("INSERT INTO users (your_name, mobile_no, email_id, Aadhar_no, Age, State, Address) VALUES (?, ?, ?, ?, ?, ?, ?)");

if ($stmt) {
    $stmt->bind_param("ssssiss", $test_name, $test_mobile, $test_email, $test_aadhar, $test_age, $test_state, $test_address);
    
    if ($stmt->execute()) {
        $inserted_id = $conn->insert_id;
        echo "<div class='success'>✓ Test insert successful! Inserted ID: $inserted_id</div>";
        
        // Clean up test data
        $conn->query("DELETE FROM users WHERE id = $inserted_id");
        echo "<div class='info'>Test data cleaned up</div>";
    } else {
        echo "<div class='error'>✗ Test insert failed: " . $stmt->error . "</div>";
    }
    $stmt->close();
} else {
    echo "<div class='error'>✗ Could not prepare test insert: " . $conn->error . "</div>";
}

$conn->close();

echo "<h2>Summary</h2>";
echo "<div class='success'><strong>✓ Database verification complete!</strong></div>";
echo "<p><a href='userform.html' class='btn'>Go to User Registration</a> ";
echo "<a href='contact.html' class='btn'>Go to Feedback Form</a> ";
echo "<a href='setup_database.php' class='btn'>Run Database Setup</a></p>";

echo "</div></body></html>";
?>




