<?php
// Create Checkout Table and Update Database
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

echo "<!DOCTYPE html>
<html>
<head>
    <title>Create Checkout Table</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; font-size: 16px; }
        .error { color: red; padding: 15px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; font-size: 16px; }
        .info { color: blue; padding: 15px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; font-size: 16px; }
        .warning { color: #856404; padding: 15px; background: #fff3cd; border: 1px solid #ffeaa7; margin: 10px 0; border-radius: 5px; font-size: 16px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .btn { display: inline-block; padding: 12px 24px; margin: 10px 5px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; font-size: 16px; }
        .btn:hover { background: #45a049; }
        h1 { color: #333; }
        h2 { color: #555; margin-top: 30px; }
    </style>
</head>
<body>
<div class='container'>
<h1>Create Checkout Table</h1>";

// Step 1: Connect to MySQL
echo "<h2>Step 1: Database Connection</h2>";
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("<div class='error'>✗ Connection failed: " . $conn->connect_error . "</div></div></body></html>");
}

echo "<div class='success'>✓ Connected to MySQL server successfully</div>";

// Step 2: Create database if it doesn't exist
echo "<h2>Step 2: Create/Select Database</h2>";
$create_db_sql = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($conn->query($create_db_sql) === TRUE) {
    echo "<div class='success'>✓ Database '$dbname' created or already exists</div>";
} else {
    echo "<div class='error'>✗ Error creating database: " . $conn->error . "</div>";
    $conn->close();
    echo "</div></body></html>";
    exit();
}

// Select the database
if (!$conn->select_db($dbname)) {
    die("<div class='error'>✗ Error selecting database: " . $conn->error . "</div></div></body></html>");
}

echo "<div class='success'>✓ Database '$dbname' selected</div>";

// Step 3: Drop existing checkout table if it exists
echo "<h2>Step 3: Drop Existing Table</h2>";
$drop_table = "DROP TABLE IF EXISTS `checkout`";
if ($conn->query($drop_table) === TRUE) {
    echo "<div class='info'>✓ Dropped existing 'checkout' table (if it existed)</div>";
} else {
    echo "<div class='warning'>⚠ Could not drop table: " . $conn->error . "</div>";
}

// Step 4: Create checkout table with correct structure
echo "<h2>Step 4: Create Checkout Table</h2>";
$create_table_sql = "CREATE TABLE `checkout` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(255) NOT NULL,
    `last_name` VARCHAR(255) NOT NULL,
    `country_name` VARCHAR(100) NOT NULL,
    `Street_Address` VARCHAR(255) NOT NULL,
    `Town_City` VARCHAR(100) NOT NULL,
    `Phone` VARCHAR(20) NOT NULL,
    `mail` VARCHAR(255) NOT NULL,
    `payment_method` VARCHAR(50) NOT NULL,
    `payment_status` VARCHAR(40) NOT NULL DEFAULT 'Pending',
    `payment_reference` VARCHAR(64) DEFAULT NULL,
    `payment_metadata` TEXT NULL,
    `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `delivery` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `terms_accepted` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_table_sql) === TRUE) {
    echo "<div class='success'>✓ Checkout table created successfully!</div>";
} else {
    echo "<div class='error'>✗ Error creating checkout table: " . $conn->error . "</div>";
    $conn->close();
    echo "</div></body></html>";
    exit();
}

// Step 5: Show table structure
echo "<h2>Step 5: Table Structure</h2>";
$result = $conn->query("DESCRIBE `checkout`");
if ($result) {
    echo "<table>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td><strong>" . $row['Field'] . "</strong></td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Step 6: Test insertion
echo "<h2>Step 6: Test Insertion</h2>";
$test_first = "Test";
$test_last = "User";
$test_country = "Delhi";
$test_street = "123 Test Street";
$test_city = "New Delhi";
$test_phone = "9876543210";
$test_mail = "test" . time() . "@example.com";
$test_payment_method = "Paypal";
$test_payment_status = "Authorized";
$test_payment_reference = "PAY-" . date('YmdHis');
$test_payment_metadata = json_encode([
    'paypal_email' => 'test.payment@example.com',
    'notes' => 'Automated test insert'
]);
$test_subtotal = 20.60;
$test_delivery = 0.00;
$test_discount = 3.00;
$test_total = 17.60;
$test_terms = 1;

$stmt = $conn->prepare("INSERT INTO checkout (first_name, last_name, country_name, Street_Address, Town_City, Phone, mail, payment_method, payment_status, payment_reference, payment_metadata, subtotal, delivery, discount, total, terms_accepted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if ($stmt) {
    $stmt->bind_param(
        "sssssssssssddddi",
        $test_first,
        $test_last,
        $test_country,
        $test_street,
        $test_city,
        $test_phone,
        $test_mail,
        $test_payment_method,
        $test_payment_status,
        $test_payment_reference,
        $test_payment_metadata,
        $test_subtotal,
        $test_delivery,
        $test_discount,
        $test_total,
        $test_terms
    );
    
    if ($stmt->execute()) {
        $test_id = $conn->insert_id;
        echo "<div class='success'>✓ Test data inserted successfully! ID: $test_id</div>";
        
        // Show the inserted record
        $result = $conn->query("SELECT * FROM checkout WHERE id = $test_id");
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "<div class='info'>";
            echo "<strong>Inserted Record:</strong><br>";
            echo "ID: " . $row['id'] . "<br>";
            echo "First Name: " . $row['first_name'] . "<br>";
            echo "Last Name: " . $row['last_name'] . "<br>";
            echo "Country: " . $row['country_name'] . "<br>";
            echo "Street Address: " . $row['Street_Address'] . "<br>";
            echo "Town/City: " . $row['Town_City'] . "<br>";
            echo "Phone: " . $row['Phone'] . "<br>";
            echo "Email: " . $row['mail'] . "<br>";
            echo "Payment Method: " . $row['payment_method'] . "<br>";
            echo "Payment Status: " . $row['payment_status'] . "<br>";
            echo "Payment Reference: " . $row['payment_reference'] . "<br>";
            echo "Subtotal: $" . $row['subtotal'] . "<br>";
            echo "Total: $" . $row['total'] . "<br>";
            echo "Created: " . $row['created_at'];
            echo "</div>";
        }
        
        // Delete test data
        $conn->query("DELETE FROM checkout WHERE id = $test_id");
        echo "<div class='info'>✓ Test data cleaned up</div>";
    } else {
        echo "<div class='error'>✗ Error inserting test data: " . $stmt->error . "</div>";
    }
    $stmt->close();
} else {
    echo "<div class='error'>✗ Error preparing statement: " . $conn->error . "</div>";
}

// Step 7: Verify table exists
echo "<h2>Step 7: Verification</h2>";
$result = $conn->query("SHOW TABLES LIKE 'checkout'");
if ($result && $result->num_rows > 0) {
    echo "<div class='success'>✓ Checkout table verified and ready to use!</div>";
} else {
    echo "<div class='error'>✗ Checkout table not found!</div>";
}

$conn->close();

echo "<div class='success' style='font-size: 18px; padding: 20px; margin-top: 30px;'>";
echo "<h2>✓ Setup Complete!</h2>";
echo "<p>The checkout table has been created successfully with the following columns:</p>";
echo "<ul style='text-align: left; display: inline-block;'>";
echo "<li>id (Auto-increment)</li>";
echo "<li>first_name</li>";
echo "<li>last_name</li>";
echo "<li>country_name</li>";
echo "<li>Street_Address</li>";
echo "<li>Town_City</li>";
echo "<li>Phone</li>";
echo "<li>mail</li>";
echo "<li>payment_method</li>";
echo "<li>payment_status</li>";
echo "<li>payment_reference</li>";
echo "<li>payment_metadata</li>";
echo "<li>subtotal</li>";
echo "<li>delivery</li>";
echo "<li>discount</li>";
echo "<li>total</li>";
echo "<li>terms_accepted</li>";
echo "<li>created_at (Timestamp)</li>";
echo "</ul>";
echo "</div>";

echo "<div style='margin-top: 30px; text-align: center;'>";
echo "<a href='checkout.html' class='btn'>Go to Checkout Form</a> ";
echo "<a href='view_checkout_data.php' class='btn'>View Checkout Data</a> ";
echo "<a href='test_checkout.php' class='btn'>Test Checkout</a>";
echo "</div>";

echo "</div></body></html>";
?>




