-- SQL File to Create Checkout Table
-- Database: liquorstore
-- Table: checkout

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS `liquorstore` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Use the database
USE `liquorstore`;

-- Drop table if exists (optional - remove this line if you want to keep existing data)
DROP TABLE IF EXISTS `checkout`;

-- Create checkout table with all required columns
CREATE TABLE `checkout` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(255) NOT NULL,
    `last_name` VARCHAR(255) NOT NULL,
    `country_name` VARCHAR(100) NOT NULL,
    `Street_Address` VARCHAR(255) NOT NULL,
    `Town_City` VARCHAR(100) NOT NULL,
    `Phone` VARCHAR(20) NOT NULL,
    `mail` VARCHAR(255) NOT NULL,
    `payment_method` VARCHAR(50) NOT NULL,
    `payment_status` VARCHAR(40) NOT NULL DEFAULT 'Pending',
    `payment_reference` VARCHAR(64) DEFAULT NULL,
    `payment_metadata` TEXT NULL,
    `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `delivery` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `terms_accepted` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Show table structure
DESCRIBE `checkout`;

-- Optional: Insert a test record
-- INSERT INTO `checkout` (`first_name`, `last_name`, `country_name`, `Street_Address`, `Town_City`, `Phone`, `mail`) 
-- VALUES ('Test', 'User', 'Delhi', '123 Test Street', 'New Delhi', '9876543210', 'test@example.com');




