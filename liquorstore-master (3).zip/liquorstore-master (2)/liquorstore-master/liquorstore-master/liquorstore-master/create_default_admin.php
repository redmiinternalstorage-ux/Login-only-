<?php
// Script to create default admin account
// Run this file once to set up default admin credentials

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$create_db_sql = "CREATE DATABASE IF NOT EXISTS " . $conn->real_escape_string($dbname);
if ($conn->query($create_db_sql)) {
    echo "Database created or already exists.<br>";
} else {
    die("Error creating database: " . $conn->error);
}

// Select database
$conn->select_db($dbname);

// Create adminpage table if it doesn't exist
$create_table_sql = "CREATE TABLE IF NOT EXISTS `adminpage` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($create_table_sql)) {
    echo "Admin table created or already exists.<br>";
} else {
    die("Error creating table: " . $conn->error);
}

// Check if admin account already exists
$check_sql = "SELECT * FROM adminpage WHERE username = 'admin'";
$result = $conn->query($check_sql);

if ($result->num_rows > 0) {
    // Update existing admin password
    $update_sql = "UPDATE adminpage SET password = 'admin' WHERE username = 'admin'";
    if ($conn->query($update_sql)) {
        echo "Default admin account password updated successfully!<br>";
        echo "Username: admin<br>";
        echo "Password: admin<br>";
    } else {
        echo "Error updating admin: " . $conn->error . "<br>";
    }
} else {
    // Create new admin account
    $default_admin = "admin";
    $default_password = "admin";
    $insert_sql = "INSERT INTO adminpage (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($insert_sql);
    
    if ($stmt) {
        $stmt->bind_param("ss", $default_admin, $default_password);
        if ($stmt->execute()) {
            echo "Default admin account created successfully!<br>";
            echo "Username: admin<br>";
            echo "Password: admin<br>";
        } else {
            echo "Error creating admin: " . $stmt->error . "<br>";
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error . "<br>";
    }
}

// Create admin_login_logs table if it doesn't exist
$create_admin_logs_table = "CREATE TABLE IF NOT EXISTS `admin_login_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) NOT NULL,
    `login_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `status` VARCHAR(20) DEFAULT 'success'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_admin_logs_table)) {
    echo "Admin login logs table created or already exists.<br>";
} else {
    echo "Error creating admin_login_logs table: " . $conn->error . "<br>";
}

// Create shops table if it doesn't exist
$create_shops_table = "CREATE TABLE IF NOT EXISTS `shops` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `shop_name` VARCHAR(255) NOT NULL,
    `owner_name` VARCHAR(255) NOT NULL,
    `contact` VARCHAR(20) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `gst_number` VARCHAR(50) DEFAULT NULL,
    `address` TEXT NOT NULL,
    `branches` INT NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($create_shops_table)) {
    echo "Shops table created or already exists.<br>";
} else {
    echo "Error creating shops table: " . $conn->error . "<br>";
}

// Verify admin account
$verify_sql = "SELECT username, password FROM adminpage WHERE username = 'admin' AND password = 'admin'";
$verify_result = $conn->query($verify_sql);

if ($verify_result->num_rows > 0) {
    echo "<br><strong style='color:green;'>✓ Admin account verified: Username 'admin' with password 'admin' is ready!</strong><br>";
} else {
    echo "<br><strong style='color:red;'>✗ Warning: Admin account verification failed!</strong><br>";
}

$conn->close();

echo "<br><strong>Setup complete!</strong><br>";
echo "<a href='adminform.php'>Go to Admin Login</a> | <a href='fix_admin_account.php'>Run Fix Script</a>";
?>

