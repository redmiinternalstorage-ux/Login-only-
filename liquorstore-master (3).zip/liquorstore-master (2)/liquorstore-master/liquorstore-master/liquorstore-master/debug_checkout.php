<?php
// Debug Checkout Form Submission
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>
<html>
<head>
    <title>Debug Checkout</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        .success { color: green; padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; }
        .error { color: red; padding: 15px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; }
        .info { color: blue; padding: 15px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; }
        .code { background: #f4f4f4; padding: 15px; border-left: 4px solid #4CAF50; margin: 10px 0; font-family: monospace; white-space: pre-wrap; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
    </style>
</head>
<body>
<div class='container'>
<h1>Debug Checkout Insertion</h1>";

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

// Connect
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div></div></body></html>");
}

$conn->select_db($dbname);

// Check if table exists
$result = $conn->query("SHOW TABLES LIKE 'checkout'");
if (!$result || $result->num_rows == 0) {
    echo "<div class='error'>✗ Checkout table does NOT exist!</div>";
    echo "<div class='info'>Please run <a href='create_checkout_table.php'>create_checkout_table.php</a> first</div>";
    $conn->close();
    echo "</div></body></html>";
    exit();
}

echo "<div class='success'>✓ Checkout table exists</div>";

// Show POST data
echo "<h2>POST Data Received:</h2>";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<div class='code'>";
    print_r($_POST);
    echo "</div>";
} else {
    echo "<div class='info'>No POST data. This page should be accessed via form submission.</div>";
    echo "<div class='info'>To test, fill out the checkout form and submit it.</div>";
}

// Test manual insert
echo "<h2>Test Manual Insert:</h2>";
$test_first = "John";
$test_last = "Doe";
$test_country = "Delhi";
$test_street = "123 Test Street";
$test_city = "New Delhi";
$test_phone = "9876543210";
$test_mail = "test" . time() . "@example.com";

$test_payment_method = "Paypal";
$test_payment_status = "Authorized";
$test_payment_reference = "PAY-" . date('YmdHis');
$test_payment_metadata = json_encode([
    'paypal_email' => $test_mail,
    'notes' => 'Debug insert'
]);
$test_subtotal = 30.00;
$test_delivery = 0.00;
$test_discount = 5.00;
$test_total = 25.00;
$test_terms = 1;

$stmt = $conn->prepare("INSERT INTO checkout (first_name, last_name, country_name, Street_Address, Town_City, Phone, mail, payment_method, payment_status, payment_reference, payment_metadata, subtotal, delivery, discount, total, terms_accepted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if ($stmt) {
    $stmt->bind_param(
        "sssssssssssddddi",
        $test_first,
        $test_last,
        $test_country,
        $test_street,
        $test_city,
        $test_phone,
        $test_mail,
        $test_payment_method,
        $test_payment_status,
        $test_payment_reference,
        $test_payment_metadata,
        $test_subtotal,
        $test_delivery,
        $test_discount,
        $test_total,
        $test_terms
    );
    
    if ($stmt->execute()) {
        $id = $conn->insert_id;
        echo "<div class='success'>✓ Test insert successful! ID: $id</div>";
        
        // Delete test
        $conn->query("DELETE FROM checkout WHERE id = $id");
        echo "<div class='info'>Test record deleted</div>";
    } else {
        echo "<div class='error'>✗ Test insert failed: " . $stmt->error . "</div>";
    }
    $stmt->close();
} else {
    echo "<div class='error'>✗ Prepare failed: " . $conn->error . "</div>";
}

// Show all records
echo "<h2>All Records in Checkout Table:</h2>";
$result = $conn->query("SELECT * FROM checkout ORDER BY id DESC LIMIT 20");
if ($result && $result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Country</th><th>Payment</th><th>Status</th><th>Total</th><th>Phone</th><th>Email</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['country_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['payment_method']) . "</td>";
        echo "<td>" . htmlspecialchars($row['payment_status']) . "</td>";
        echo "<td>$" . htmlspecialchars($row['total']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Phone']) . "</td>";
        echo "<td>" . htmlspecialchars($row['mail']) . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='info'>No records found in checkout table.</div>";
}

$conn->close();

echo "<p><a href='checkout.html'>Go to Checkout Form</a> | <a href='create_checkout_table.php'>Create Table</a></p>";
echo "</div></body></html>";
?>




