<?php
// Script to fix admin account and database setup
// This will ensure username: admin, password: admin works correctly

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

echo "<!DOCTYPE html><html><head><title>Fix Admin Account</title>";
echo "<style>body{font-family:Arial;padding:20px;background:#f5f5f5;}";
echo ".success{color:green;background:#d4edda;padding:10px;margin:10px 0;border-radius:5px;}";
echo ".error{color:red;background:#f8d7da;padding:10px;margin:10px 0;border-radius:5px;}";
echo ".info{color:blue;background:#d1ecf1;padding:10px;margin:10px 0;border-radius:5px;}";
echo "a{color:#007bff;text-decoration:none;font-weight:bold;}";
echo "</style></head><body>";
echo "<h1>Admin Account Setup & Fix</h1>";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div>");
}
echo "<div class='success'>✓ Connected to MySQL server</div>";

// Create database if it doesn't exist
$create_db_sql = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($conn->query($create_db_sql)) {
    echo "<div class='success'>✓ Database '$dbname' created or already exists</div>";
} else {
    die("<div class='error'>✗ Error creating database: " . $conn->error . "</div>");
}

// Select database
if (!$conn->select_db($dbname)) {
    die("<div class='error'>✗ Error selecting database: " . $conn->error . "</div>");
}
echo "<div class='success'>✓ Selected database '$dbname'</div>";

// Create adminpage table if it doesn't exist
$create_adminpage_table = "CREATE TABLE IF NOT EXISTS `adminpage` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_adminpage_table)) {
    echo "<div class='success'>✓ Table 'adminpage' created or already exists</div>";
} else {
    die("<div class='error'>✗ Error creating adminpage table: " . $conn->error . "</div>");
}

// Create admin_login_logs table if it doesn't exist
$create_admin_logs_table = "CREATE TABLE IF NOT EXISTS `admin_login_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) NOT NULL,
    `login_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `status` VARCHAR(20) DEFAULT 'success'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_admin_logs_table)) {
    echo "<div class='success'>✓ Table 'admin_login_logs' created or already exists</div>";
} else {
    echo "<div class='error'>✗ Error creating admin_login_logs table: " . $conn->error . "</div>";
}

// Check if admin account exists
$check_sql = "SELECT * FROM adminpage WHERE username = 'admin'";
$result = $conn->query($check_sql);

if ($result->num_rows > 0) {
    // Admin exists - update password to ensure it's "admin"
    $update_sql = "UPDATE adminpage SET password = 'admin' WHERE username = 'admin'";
    if ($conn->query($update_sql)) {
        echo "<div class='success'>✓ Admin account password updated to 'admin'</div>";
    } else {
        echo "<div class='error'>✗ Error updating admin password: " . $conn->error . "</div>";
    }
} else {
    // Admin doesn't exist - create it
    $default_admin = "admin";
    $default_password = "admin";
    $insert_sql = "INSERT INTO adminpage (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($insert_sql);
    
    if ($stmt) {
        $stmt->bind_param("ss", $default_admin, $default_password);
        if ($stmt->execute()) {
            echo "<div class='success'>✓ Default admin account created successfully!</div>";
        } else {
            echo "<div class='error'>✗ Error creating admin: " . $stmt->error . "</div>";
        }
        $stmt->close();
    } else {
        echo "<div class='error'>✗ Error preparing statement: " . $conn->error . "</div>";
    }
}

// Verify admin account
$verify_sql = "SELECT username, password FROM adminpage WHERE username = 'admin' AND password = 'admin'";
$verify_result = $conn->query($verify_sql);

if ($verify_result->num_rows > 0) {
    $row = $verify_result->fetch_assoc();
    echo "<div class='success'>✓ Admin account verified successfully!</div>";
    echo "<div class='info'><strong>Login Credentials:</strong><br>";
    echo "Username: <strong>admin</strong><br>";
    echo "Password: <strong>admin</strong></div>";
} else {
    echo "<div class='error'>✗ Warning: Admin account verification failed. Please check manually.</div>";
}

// Show all admin accounts
echo "<div class='info'><strong>All Admin Accounts in Database:</strong><br>";
$all_admins = $conn->query("SELECT id, username, created_at FROM adminpage");
if ($all_admins->num_rows > 0) {
    echo "<table border='1' cellpadding='5' style='border-collapse:collapse;margin-top:10px;'>";
    echo "<tr><th>ID</th><th>Username</th><th>Created At</th></tr>";
    while ($admin = $all_admins->fetch_assoc()) {
        echo "<tr><td>" . $admin['id'] . "</td><td>" . htmlspecialchars($admin['username']) . "</td><td>" . $admin['created_at'] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No admin accounts found.";
}
echo "</div>";

$conn->close();

echo "<br><div class='info'><strong>Setup Complete!</strong><br>";
echo "<a href='adminform.php'>Go to Admin Login Page</a></div>";
echo "</body></html>";
?>


