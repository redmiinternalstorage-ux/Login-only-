(function () {
  const FAVORITES_KEY = 'ls_favorites_v1';
  const CART_KEY = 'ls_cart_v1';

  const state = {
    favorites: new Set(loadFromStorage(FAVORITES_KEY, [])),
    cart: loadFromStorage(CART_KEY, []),
  };

  function slugify(value) {
    return value
      .toString()
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
  }

  function loadFromStorage(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (err) {
      console.warn('Unable to read storage key', key, err);
      return fallback;
    }
  }

  function saveToStorage(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (err) {
      console.warn('Unable to persist storage key', key, err);
    }
  }

  function ensureMiniCartShells() {
    document.querySelectorAll('.btn-cart').forEach((trigger) => {
      const counterWrap = trigger.querySelector('div');
      if (counterWrap && !counterWrap.querySelector('[data-cart-count]')) {
        counterWrap.innerHTML = '<small data-cart-count>0</small>';
      }

      const dropdown = trigger.parentElement.querySelector('.dropdown-menu');
      if (!dropdown) return;
      if (!dropdown.querySelector('[data-cart-items]')) {
        dropdown.innerHTML = `
          <div class="dropdown-item text-center text-muted small" data-cart-empty>Your cart is empty</div>
          <div class="mini-cart-items" data-cart-items></div>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item text-center btn-link d-block w-100" href="cart.html">
            View All
            <span class="ion-ios-arrow-round-forward"></span>
          </a>
        `;
      }
    });
  }

  function normalizeActionButtons() {
    document.querySelectorAll('.meta-prod a').forEach((anchor) => {
      if (anchor.dataset.action) return;
      const icon = anchor.querySelector('span');
      if (!icon) return;
      if (/flaticon-heart/.test(icon.className)) {
        anchor.dataset.action = 'toggle-favorite';
        anchor.setAttribute('aria-label', anchor.getAttribute('aria-label') || 'Add to favourites');
      } else if (/flaticon-shopping-bag/.test(icon.className)) {
        anchor.dataset.action = 'add-to-cart';
        anchor.setAttribute('aria-label', anchor.getAttribute('aria-label') || 'Add to cart');
      }
    });
  }

  function getProductContext(element) {
    const card = element.closest('.product');
    if (!card) return null;

    const data = {
      id: card.dataset.productId || slugify(card.querySelector('h2')?.textContent || 'product'),
      name: card.dataset.productName || card.querySelector('h2')?.textContent?.trim() || 'Unknown product',
      price: parseFloat(card.dataset.productPrice || extractPrice(card)),
      image: card.dataset.productImage || extractImage(card),
    };

    card.dataset.productId = data.id;
    card.dataset.productName = data.name;
    card.dataset.productPrice = data.price.toFixed(2);
    card.dataset.productImage = data.image;

    return data;
  }

  function extractPrice(card) {
    const priceEl = card.querySelector('.price-sale, .price');
    if (!priceEl) return 0;
    const match = priceEl.textContent.replace(/[^0-9.]/g, '');
    return parseFloat(match || '0');
  }

  function extractImage(card) {
    const imgEl = card.querySelector('.img');
    if (!imgEl) return '';
    const style = imgEl.getAttribute('style') || '';
    const match = /url\(([^)]+)\)/.exec(style);
    return match ? match[1].replace(/['"]/g, '') : '';
  }

  function toggleFavorite(product) {
    const { id, name } = product;
    if (state.favorites.has(id)) {
      state.favorites.delete(id);
      removeFromCart(id, true);
      showToast(`${name} removed from cart`);
    } else {
      state.favorites.add(id);
      addToCart(product, 1, true);
      showToast(`${name} added to cart`);
    }
    saveToStorage(FAVORITES_KEY, Array.from(state.favorites));
    updateFavoriteButtons();
  }

  function updateFavoriteButtons() {
    document.querySelectorAll('[data-action="toggle-favorite"]').forEach((btn) => {
      const product = getProductContext(btn);
      if (!product) return;
      const isFavorite = state.favorites.has(product.id);
      btn.classList.toggle('is-active', isFavorite);
      btn.setAttribute('aria-pressed', isFavorite ? 'true' : 'false');
    });
  }

  function addToCart(product, quantity = 1, silent = false) {
    const existing = state.cart.find((item) => item.id === product.id);
    if (existing) {
      existing.quantity += quantity;
    } else {
      state.cart.push({ ...product, quantity });
    }
    saveToStorage(CART_KEY, state.cart);
    updateCartUI();
    if (!silent) {
      showToast(`${product.name} added to cart`);
    }
  }

  function removeFromCart(productId, silent = false) {
    const removed = state.cart.find((item) => item.id === productId);
    state.cart = state.cart.filter((item) => item.id !== productId);
    saveToStorage(CART_KEY, state.cart);
    updateCartUI();
    if (!silent && removed) {
      showToast(`${removed.name} removed from cart`);
    }
  }

  function updateCartUI() {
    const count = state.cart.reduce((sum, item) => sum + item.quantity, 0);
    document.querySelectorAll('[data-cart-count]').forEach((badge) => {
      badge.textContent = count;
    });

    document.querySelectorAll('[data-cart-empty]').forEach((el) => {
      el.style.display = count === 0 ? 'block' : 'none';
    });

    document.querySelectorAll('[data-cart-items]').forEach((container) => {
      container.innerHTML = '';
      state.cart.slice(0, 5).forEach((item) => {
        const row = document.createElement('div');
        row.className = 'dropdown-item d-flex align-items-start mini-cart-item';
        row.innerHTML = `
          <div class="img" style="background-image:url(${item.image});"></div>
          <div class="text pl-3">
            <h4>${item.name}</h4>
            <p class="mb-0"><span class="price">$${item.price.toFixed(2)}</span><span class="quantity ml-3">Qty: ${item.quantity}</span></p>
          </div>
          <button class="btn btn-link text-danger p-0 ml-auto" data-action="remove-cart-item" data-product-id="${item.id}" aria-label="Remove ${item.name}">&times;</button>
        `;
        container.appendChild(row);
      });
      if (count > 5) {
        const more = document.createElement('p');
        more.className = 'dropdown-item small text-muted mb-0';
        more.textContent = `+${count - 5} more item(s) in cart`;
        container.appendChild(more);
      }
    });

    renderCartTable();
  }

  function renderCartTable() {
    const tableBody = document.querySelector('[data-cart-table]');
    if (!tableBody) return;

    tableBody.innerHTML = '';
    if (state.cart.length === 0) {
      const row = document.createElement('tr');
      row.innerHTML = '<td colspan="6" class="text-center text-muted py-5">Your cart is empty.</td>';
      tableBody.appendChild(row);
    } else {
      state.cart.forEach((item) => {
        const row = document.createElement('tr');
        row.className = 'alert';
        row.innerHTML = `
          <td>
            <div class="img" style="background-image: url(${item.image});"></div>
          </td>
          <td>
            <div class="email">
              <span>${item.name}</span>
              <span>Enjoy responsibly</span>
            </div>
          </td>
          <td>$${item.price.toFixed(2)}</td>
          <td class="quantity">
            <div class="input-group">
              <input type="number" class="quantity form-control" min="1" value="${item.quantity}" data-cart-qty data-product-id="${item.id}">
            </div>
          </td>
          <td>$${(item.price * item.quantity).toFixed(2)}</td>
          <td>
            <button type="button" class="close" data-action="remove-cart-item" data-product-id="${item.id}" aria-label="Remove ${item.name}">
              <span aria-hidden="true"><i class="fa fa-close"></i></span>
            </button>
          </td>
        `;
        tableBody.appendChild(row);
      });
    }

    const subtotal = state.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const delivery = subtotal > 0 ? 0 : 0;
    const discount = subtotal * 0.05;
    const total = subtotal - discount + delivery;

    setText('[data-cart-subtotal]', `$${subtotal.toFixed(2)}`);
    setText('[data-cart-delivery]', `$${delivery.toFixed(2)}`);
    setText('[data-cart-discount]', `-$${discount.toFixed(2)}`);
    setText('[data-cart-total]', `$${total.toFixed(2)}`);
  }

  function setText(selector, value) {
    document.querySelectorAll(selector).forEach((el) => (el.textContent = value));
  }

  function showToast(message) {
    let toast = document.querySelector('.cart-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'cart-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('visible');
    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => toast.classList.remove('visible'), 1800);
  }

  function onDocumentClick(event) {
    const favBtn = event.target.closest('[data-action="toggle-favorite"]');
    if (favBtn) {
      event.preventDefault();
      const product = getProductContext(favBtn);
      if (product) {
        toggleFavorite(product);
      }
      return;
    }

    const cartBtn = event.target.closest('[data-action="add-to-cart"]');
    if (cartBtn) {
      event.preventDefault();
      const product = getProductContext(cartBtn);
      if (product) {
        addToCart(product, 1);
      }
      return;
    }

    const removeBtn = event.target.closest('[data-action="remove-cart-item"]');
    if (removeBtn) {
      event.preventDefault();
      const productId = removeBtn.dataset.productId;
      if (productId) {
        removeFromCart(productId);
      }
    }
  }

  function onInputChange(event) {
    const qtyInput = event.target.closest('[data-cart-qty]');
    if (!qtyInput) return;
    const productId = qtyInput.dataset.productId;
    const qty = Math.max(1, parseInt(qtyInput.value || '1', 10));
    const cartItem = state.cart.find((item) => item.id === productId);
    if (cartItem) {
      cartItem.quantity = qty;
      saveToStorage(CART_KEY, state.cart);
      updateCartUI();
    }
  }

  function init() {
    normalizeActionButtons();
    ensureMiniCartShells();
    document.addEventListener('click', onDocumentClick);
    document.addEventListener('input', onInputChange);
    updateFavoriteButtons();
    updateCartUI();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

