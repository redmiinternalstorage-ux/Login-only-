<?php
// Database connection
$servername = "localhost";
$username = "root";   // default XAMPP username
$password = "";       // default XAMPP password
$dbname = "liquorstore";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Select database
if (!$conn->select_db($dbname)) {
    // Database doesn't exist, try to create it
    $create_db_sql = "CREATE DATABASE IF NOT EXISTS " . $conn->real_escape_string($dbname);
    if ($conn->query($create_db_sql)) {
        $conn->select_db($dbname);
    } else {
        die("Error creating database: " . $conn->error);
    }
}

// Check if adminpage table exists, create if it doesn't
$table_check = $conn->query("SHOW TABLES LIKE 'adminpage'");
if ($table_check->num_rows == 0) {
    // Create adminpage table if it doesn't exist
    $create_table_sql = "CREATE TABLE IF NOT EXISTS `adminpage` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `username` VARCHAR(255) NOT NULL UNIQUE,
        `password` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    if (!$conn->query($create_table_sql)) {
        die("Error creating adminpage table: " . $conn->error);
    }
}

// Check if form was submitted
if (!isset($_POST['username']) || !isset($_POST['password'])) {
    die("Please enter both username and password!");
}

// Get form values and sanitize
$user = trim($_POST['username']);
$pass = trim($_POST['password']);

// Validate input
if (empty($user) || empty($pass)) {
    die("Username and password cannot be empty!");
}

// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("INSERT INTO adminpage (username, password) VALUES (?, ?)");

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

// Bind parameters
$bind_result = $stmt->bind_param("ss", $user, $pass);

if ($bind_result === false) {
    die("Error binding parameters: " . $stmt->error);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login Result</title>
    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            padding: 40px;
        }
        .box {
            width: 400px;
            background: #fff;
            padding: 25px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
            text-align: center;
        }
        a {
            color: green;
            font-size: 18px;
        }
    </style>
</head>
<body>

<div class="box">
<?php

// Execute statement
if ($stmt->execute()) {
    echo "<h2>Admin Credentials Stored Successfully</h2>";
    echo "<p><strong>Username:</strong> " . htmlspecialchars($user) . "</p>";
    echo "<p><strong>Password:</strong> " . htmlspecialchars($pass) . "</p>";
    echo "<br><a href='adminform.php'>Go to Admin Login</a> | <a href='index.html'>Go to Homepage</a>";
} 
else {
    if (strpos($stmt->error, 'Duplicate entry') !== false) {
        echo "<h2>Error: Username Already Exists</h2>";
        echo "<p>This username is already registered. Please choose a different username.</p>";
    } else {
        echo "<h2>Error Storing Credentials</h2>";
        echo "<p>Error: " . htmlspecialchars($stmt->error) . "</p>";
    }
    echo "<br><a href='index.html'>Go to Homepage</a>";
}

$stmt->close();
$conn->close();
?>
</div>

</body>
</html>
