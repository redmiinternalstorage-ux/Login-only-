<?php
// Run SQL File Script
// This script will execute the create_checkout_table.sql file

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

echo "<!DOCTYPE html>
<html>
<head>
    <title>Run SQL File</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; }
        .error { color: red; padding: 15px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; }
        .info { color: blue; padding: 15px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; }
        .code { background: #f4f4f4; padding: 15px; border-left: 4px solid #4CAF50; margin: 10px 0; font-family: monospace; white-space: pre-wrap; }
        .btn { display: inline-block; padding: 12px 24px; margin: 10px 5px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
        .btn:hover { background: #45a049; }
    </style>
</head>
<body>
<div class='container'>
<h1>Run SQL File - Create Checkout Table</h1>";

// Connect to MySQL
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div></div></body></html>");
}

echo "<div class='success'>✓ Connected to MySQL server</div>";

// Read SQL file
$sql_file = 'create_checkout_table.sql';
if (!file_exists($sql_file)) {
    die("<div class='error'>SQL file '$sql_file' not found!</div></div></body></html>");
}

echo "<div class='info'>Reading SQL file: $sql_file</div>";

$sql_content = file_get_contents($sql_file);

// Remove comments and split by semicolons
$sql_commands = array_filter(
    array_map('trim', explode(';', $sql_content)),
    function($cmd) {
        return !empty($cmd) && 
               !preg_match('/^--/', $cmd) && 
               !preg_match('/^\/\*/', $cmd) &&
               strtoupper(trim($cmd)) !== 'USE `liquorstore`';
    }
);

echo "<div class='info'>Found " . count($sql_commands) . " SQL commands to execute</div>";

$success_count = 0;
$error_count = 0;

// Execute each SQL command
foreach ($sql_commands as $index => $sql) {
    $sql = trim($sql);
    if (empty($sql) || strpos($sql, '--') === 0) {
        continue;
    }
    
    // Skip DESCRIBE and SELECT statements for now
    if (stripos($sql, 'DESCRIBE') === 0 || stripos($sql, 'SELECT') === 0 || stripos($sql, 'INSERT') === 0) {
        continue;
    }
    
    if ($conn->multi_query($sql)) {
        do {
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->next_result());
        
        $success_count++;
        echo "<div class='success'>✓ Command " . ($index + 1) . " executed successfully</div>";
    } else {
        $error_count++;
        echo "<div class='error'>✗ Error in command " . ($index + 1) . ": " . $conn->error . "</div>";
        echo "<div class='code'>" . htmlspecialchars(substr($sql, 0, 200)) . "...</div>";
    }
}

// Select database
$conn->select_db($dbname);

// Verify table was created
$result = $conn->query("SHOW TABLES LIKE 'checkout'");
if ($result && $result->num_rows > 0) {
    echo "<div class='success'><h2>✓ Checkout table created successfully!</h2></div>";
    
    // Show table structure
    $result = $conn->query("DESCRIBE `checkout`");
    if ($result) {
        echo "<h3>Table Structure:</h3>";
        echo "<table border='1' cellpadding='10' style='width: 100%; border-collapse: collapse;'>";
        echo "<tr style='background: #4CAF50; color: white;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td><strong>" . $row['Field'] . "</strong></td>";
            echo "<td>" . $row['Type'] . "</td>";
            echo "<td>" . $row['Null'] . "</td>";
            echo "<td>" . $row['Key'] . "</td>";
            echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} else {
    echo "<div class='error'>✗ Checkout table was not created!</div>";
}

$conn->close();

echo "<div class='info' style='margin-top: 30px;'>";
echo "<strong>Summary:</strong><br>";
echo "Successfully executed: $success_count commands<br>";
echo "Errors: $error_count commands";
echo "</div>";

echo "<div style='margin-top: 30px; text-align: center;'>";
echo "<a href='checkout.html' class='btn'>Go to Checkout Form</a> ";
echo "<a href='view_checkout_data.php' class='btn'>View Checkout Data</a> ";
echo "<a href='create_checkout_table.php' class='btn'>Create Table (PHP)</a>";
echo "</div>";

echo "</div></body></html>";
?>




