<?php
// Database Setup Script
// Run this file once to create/update your database and tables

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection settings
$servername = "localhost";
$username = "root";   // default XAMPP username
$password = "";       // default XAMPP password
$dbname = "liquorstore";

echo "<h1>Database Setup Script</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
    .success { color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; }
    .error { color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; }
    .info { color: blue; padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; }
</style>";

// Create connection without specifying database
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div>");
}

echo "<div class='success'>✓ Connected to MySQL server successfully</div>";

// Create database if it doesn't exist
$create_db_sql = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($conn->query($create_db_sql) === TRUE) {
    echo "<div class='success'>✓ Database '$dbname' created or already exists</div>";
} else {
    echo "<div class='error'>✗ Error creating database: " . $conn->error . "</div>";
    die();
}

// Select the database
if (!$conn->select_db($dbname)) {
    die("<div class='error'>✗ Error selecting database: " . $conn->error . "</div>");
}

echo "<div class='success'>✓ Database '$dbname' selected</div>";

// Create users table
$create_users_table = "CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `your_name` VARCHAR(255) NOT NULL,
    `mobile_no` VARCHAR(20) NOT NULL,
    `email_id` VARCHAR(255) NOT NULL,
    `Aadhar_no` VARCHAR(20) NOT NULL,
    `Age` INT NOT NULL,
    `State` VARCHAR(100) NOT NULL,
    `Address` TEXT NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_email` (`email_id`),
    UNIQUE KEY `unique_mobile` (`mobile_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_users_table) === TRUE) {
    echo "<div class='success'>✓ Table 'users' created or already exists</div>";
} else {
    echo "<div class='error'>✗ Error creating users table: " . $conn->error . "</div>";
}

// Create feedback table
$create_feedback_table = "CREATE TABLE IF NOT EXISTS `feedback` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `full_name` VARCHAR(255) NOT NULL,
    `email_address` VARCHAR(255) NOT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_feedback_table) === TRUE) {
    echo "<div class='success'>✓ Table 'feedback' created or already exists</div>";
} else {
    echo "<div class='error'>✗ Error creating feedback table: " . $conn->error . "</div>";
}

// Create adminpage table (if it doesn't exist)
$create_adminpage_table = "CREATE TABLE IF NOT EXISTS `adminpage` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_adminpage_table) === TRUE) {
    echo "<div class='success'>✓ Table 'adminpage' created or already exists</div>";
} else {
    echo "<div class='error'>✗ Error creating adminpage table: " . $conn->error . "</div>";
}

// Create admin_login_logs table
$create_admin_logs_table = "CREATE TABLE IF NOT EXISTS `admin_login_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) NOT NULL,
    `login_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `status` VARCHAR(20) DEFAULT 'success'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_admin_logs_table) === TRUE) {
    echo "<div class='success'>✓ Table 'admin_login_logs' created or already exists</div>";
} else {
    echo "<div class='error'>✗ Error creating admin_login_logs table: " . $conn->error . "</div>";
}

// Drop orders table if exists and recreate it
$drop_orders_table = "DROP TABLE IF EXISTS `orders`";
if ($conn->query($drop_orders_table) === TRUE) {
    echo "<div class='info'>✓ Dropped existing 'orders' table</div>";
}

// Create orders table with correct structure
$create_orders_table = "CREATE TABLE `orders` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(255) NOT NULL,
    `last_name` VARCHAR(255) NOT NULL,
    `state_country` VARCHAR(100) NOT NULL,
    `street_address` VARCHAR(255) NOT NULL,
    `apartment` VARCHAR(255) DEFAULT NULL,
    `town_city` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `payment_method` VARCHAR(50) NOT NULL,
    `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `delivery` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `order_status` VARCHAR(50) DEFAULT 'Pending',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_orders_table) === TRUE) {
    echo "<div class='success'>✓ Table 'orders' created successfully</div>";
} else {
    echo "<div class='error'>✗ Error creating orders table: " . $conn->error . "</div>";
}


// Test insert into users table
echo "<div class='info'>Testing database insertion...</div>";

$test_name = "Test User " . date('Y-m-d H:i:s');
$test_mobile = "9999999999";
$test_email = "test" . time() . "@example.com";
$test_aadhar = "123456789012";
$test_age = 25;
$test_state = "Delhi";
$test_address = "Test Address";

$stmt = $conn->prepare("INSERT INTO users (your_name, mobile_no, email_id, Aadhar_no, Age, State, Address) VALUES (?, ?, ?, ?, ?, ?, ?)");

if ($stmt) {
    $stmt->bind_param("ssssiss", $test_name, $test_mobile, $test_email, $test_aadhar, $test_age, $test_state, $test_address);
    
    if ($stmt->execute()) {
        $inserted_id = $conn->insert_id;
        echo "<div class='success'>✓ Test data inserted successfully! Inserted ID: $inserted_id</div>";
        
        // Delete test data
        $conn->query("DELETE FROM users WHERE id = $inserted_id");
        echo "<div class='info'>Test data cleaned up</div>";
    } else {
        echo "<div class='error'>✗ Error inserting test data: " . $stmt->error . "</div>";
    }
    $stmt->close();
} else {
    echo "<div class='error'>✗ Error preparing test statement: " . $conn->error . "</div>";
}

// Show table status
echo "<h2>Database Tables Status:</h2>";
$tables = ['users', 'feedback', 'adminpage', 'admin_login_logs', 'orders'];

foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        $count_result = $conn->query("SELECT COUNT(*) as count FROM `$table`");
        $count_row = $count_result->fetch_assoc();
        $count = $count_row['count'];
        echo "<div class='info'>Table '$table': $count records</div>";
    } else {
        echo "<div class='error'>Table '$table': NOT FOUND</div>";
    }
}

$conn->close();

echo "<div class='success'><h2>✓ Database setup completed!</h2></div>";
echo "<p><a href='userform.html'>Go to User Registration Form</a> | <a href='contact.html'>Go to Feedback Form</a></p>";
?>

