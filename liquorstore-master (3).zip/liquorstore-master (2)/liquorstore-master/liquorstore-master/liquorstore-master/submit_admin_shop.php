<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";   // default XAMPP username
$password = "";       // default XAMPP password
$dbname = "liquorstore";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    $_SESSION['shop_error'] = "Database connection failed. Please contact administrator.";
    header("Location: adminshope.php");
    exit();
}

// Select database
if (!$conn->select_db($dbname)) {
    // Database doesn't exist, try to create it
    $create_db_sql = "CREATE DATABASE IF NOT EXISTS " . $conn->real_escape_string($dbname);
    if ($conn->query($create_db_sql)) {
        $conn->select_db($dbname);
    } else {
        $_SESSION['shop_error'] = "Database not found. Please run setup_database.php first.";
        $conn->close();
        header("Location: adminshope.php");
        exit();
    }
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $_SESSION['shop_error'] = "Invalid request method.";
    header("Location: adminshope.php");
    exit();
}

// Get form values and sanitize
$shopName = isset($_POST['shopName']) ? trim($_POST['shopName']) : '';
$ownerName = isset($_POST['ownerName']) ? trim($_POST['ownerName']) : '';
$contact = isset($_POST['contact']) ? trim($_POST['contact']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$gst = isset($_POST['gst']) ? trim($_POST['gst']) : '';
$address = isset($_POST['address']) ? trim($_POST['address']) : '';
$quantity = isset($_POST['quantity']) ? intval(trim($_POST['quantity'])) : 0;

// Validate required fields
if (empty($shopName) || empty($ownerName) || empty($contact) || empty($email) || empty($address) || $quantity <= 0) {
    $_SESSION['shop_error'] = "Please fill in all required fields!";
    header("Location: adminshope.php");
    exit();
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['shop_error'] = "Please enter a valid email address!";
    header("Location: adminshope.php");
    exit();
}

// Validate contact number (should be 10 digits)
if (!preg_match('/^[0-9]{10}$/', $contact)) {
    $_SESSION['shop_error'] = "Contact number must be exactly 10 digits!";
    header("Location: adminshope.php");
    exit();
}

// Check if shops table exists, create if it doesn't
$table_check = $conn->query("SHOW TABLES LIKE 'shops'");
if ($table_check->num_rows == 0) {
    // Create shops table if it doesn't exist
    $create_table_sql = "CREATE TABLE IF NOT EXISTS `shops` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `shop_name` VARCHAR(255) NOT NULL,
        `owner_name` VARCHAR(255) NOT NULL,
        `contact` VARCHAR(20) NOT NULL,
        `email` VARCHAR(255) NOT NULL,
        `gst_number` VARCHAR(50) DEFAULT NULL,
        `address` TEXT NOT NULL,
        `branches` INT NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    if (!$conn->query($create_table_sql)) {
        $_SESSION['shop_error'] = "Database error: Could not create shops table. Error: " . $conn->error;
        $conn->close();
        header("Location: adminshope.php");
        exit();
    }
}

// Prepare statement to prevent SQL injection
$stmt = $conn->prepare("INSERT INTO shops (shop_name, owner_name, contact, email, gst_number, address, branches) VALUES (?, ?, ?, ?, ?, ?, ?)");

// Check if prepare was successful
if ($stmt === false) {
    $_SESSION['shop_error'] = "Database error. Please try again later. Error: " . $conn->error;
    $conn->close();
    header("Location: adminshope.php");
    exit();
}

// Bind parameters
$bind_result = $stmt->bind_param("ssssssi", $shopName, $ownerName, $contact, $email, $gst, $address, $quantity);

// Check if bind was successful
if ($bind_result === false) {
    $_SESSION['shop_error'] = "Database error. Please try again later.";
    $stmt->close();
    $conn->close();
    header("Location: adminshope.php");
    exit();
}

// Execute statement
$execute_result = $stmt->execute();

// Check if execute was successful
if ($execute_result === false) {
    $error_msg = "Error saving shop information. Please try again. Error: " . $stmt->error;
    $_SESSION['shop_error'] = $error_msg;
    // Log error for debugging
    error_log("Shop form submission error: " . $stmt->error);
    $stmt->close();
    $conn->close();
    header("Location: adminshope.php");
    exit();
}

// Get the inserted ID to confirm success
$inserted_id = $conn->insert_id;

// Success - store success message
$_SESSION['shop_success'] = "Shop information saved successfully! Shop Name: " . htmlspecialchars($shopName) . " (ID: " . $inserted_id . ")";

// Close statement and connection
$stmt->close();
$conn->close();

// Redirect to success page or back to form
header("Location: adminshope.php");
exit();
?>

