<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to user, but log them

function normalize_amount($value, $default = 0.00) {
    if ($value === null || $value === '') {
        return $default;
    }
    $sanitized = preg_replace('/[^0-9\.\-]/', '', $value);
    if ($sanitized === '' || !is_numeric($sanitized)) {
        return $default;
    }
    return round((float)$sanitized, 2);
}

function generate_payment_reference($method) {
    $prefix = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', $method), 0, 3));
    if ($prefix === '') {
        $prefix = 'PAY';
    }
    return $prefix . '-' . date('YmdHis') . '-' . random_int(100, 999);
}

function process_payment($method, $total, $meta = []) {
    $safeTotal = (float)$total;
    if ($safeTotal <= 0) {
        return [
            'status' => 'Failed',
            'reference' => null,
            'message' => 'Invalid order amount'
        ];
    }

    $status = 'Pending';
    $message = 'Payment details captured';

    switch ($method) {
        case 'Direct Bank Transfer':
            $status = 'Awaiting Verification';
            $message = 'Bank transfer reference received. We will confirm within 15 minutes.';
            break;
        case 'Check Payment':
            $status = 'Awaiting Clearance';
            $message = 'Cheque details captured. Delivery will be scheduled after clearance.';
            break;
        case 'Paypal':
        case 'UPI':
            $status = 'Authorized';
            $message = 'Payment request sent. Awaiting confirmation.';
            break;
        default:
            $status = 'Pending';
            $message = 'Payment method recorded.';
    }

    return [
        'status' => $status,
        'reference' => generate_payment_reference($method),
        'message' => $message,
        'meta' => $meta
    ];
}

function ensure_checkout_columns($conn) {
    $columns = [
        'payment_method' => "ALTER TABLE `checkout` ADD COLUMN `payment_method` VARCHAR(50) NOT NULL AFTER `mail`",
        'payment_status' => "ALTER TABLE `checkout` ADD COLUMN `payment_status` VARCHAR(40) NOT NULL DEFAULT 'Pending' AFTER `payment_method`",
        'payment_reference' => "ALTER TABLE `checkout` ADD COLUMN `payment_reference` VARCHAR(64) DEFAULT NULL AFTER `payment_status`",
        'payment_metadata' => "ALTER TABLE `checkout` ADD COLUMN `payment_metadata` TEXT NULL AFTER `payment_reference`",
        'subtotal' => "ALTER TABLE `checkout` ADD COLUMN `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `payment_metadata`",
        'delivery' => "ALTER TABLE `checkout` ADD COLUMN `delivery` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `subtotal`",
        'discount' => "ALTER TABLE `checkout` ADD COLUMN `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `delivery`",
        'total' => "ALTER TABLE `checkout` ADD COLUMN `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `discount`",
        'terms_accepted' => "ALTER TABLE `checkout` ADD COLUMN `terms_accepted` TINYINT(1) NOT NULL DEFAULT 0 AFTER `total`"
    ];

    foreach ($columns as $column => $statement) {
        $check = $conn->query("SHOW COLUMNS FROM `checkout` LIKE '$column'");
        if ($check && $check->num_rows === 0) {
            if ($conn->query($statement) === FALSE) {
                error_log("Checkout schema update failed for $column: " . $conn->error);
                return false;
            }
        }
    }

    return true;
}

// Database connection
$servername = "localhost";
$username = "root";   // default XAMPP username
$password = "";       // default XAMPP password
$dbname = "liquorstore";

// Create connection without specifying database first
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    error_log("Checkout DB Connection failed: " . $conn->connect_error);
    header("Location: checkout.html?error=db&msg=" . urlencode("Connection failed: " . $conn->connect_error));
    exit();
}

// Create database if it doesn't exist
$create_db_sql = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($conn->query($create_db_sql) === FALSE) {
    error_log("Checkout DB Create failed: " . $conn->error);
    header("Location: checkout.html?error=db&msg=" . urlencode("Error creating database: " . $conn->error));
    exit();
}

// Select the database
if (!$conn->select_db($dbname)) {
    error_log("Checkout DB Select failed: " . $conn->error);
    header("Location: checkout.html?error=db&msg=" . urlencode("Error selecting database: " . $conn->error));
    exit();
}

// Log received POST data for debugging
error_log("Checkout POST data: " . print_r($_POST, true));

// Get form values and sanitize
$first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
$last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
$country_name = isset($_POST['state_country']) ? trim($_POST['state_country']) : '';
$Street_Address = isset($_POST['street_address']) ? trim($_POST['street_address']) : '';
$Town_City = isset($_POST['town_city']) ? trim($_POST['town_city']) : '';
$Phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$mail = isset($_POST['email']) ? trim($_POST['email']) : '';
$payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : '';
$terms_accepted = isset($_POST['terms_accepted']) ? 1 : 0;
$subtotal = normalize_amount($_POST['subtotal'] ?? 0);
$delivery = normalize_amount($_POST['delivery'] ?? 0);
$discount = normalize_amount($_POST['discount'] ?? 0);
$total = normalize_amount($_POST['total'] ?? 0);

$bank_account_name = isset($_POST['bank_account_name']) ? trim($_POST['bank_account_name']) : '';
$bank_reference = isset($_POST['bank_reference']) ? trim($_POST['bank_reference']) : '';
$check_holder = isset($_POST['check_holder']) ? trim($_POST['check_holder']) : '';
$check_number = isset($_POST['check_number']) ? trim($_POST['check_number']) : '';
$paypal_email = isset($_POST['paypal_email']) ? trim($_POST['paypal_email']) : '';
$upi_id = isset($_POST['upi_id']) ? trim($_POST['upi_id']) : '';
$payment_notes = isset($_POST['payment_notes']) ? trim($_POST['payment_notes']) : '';

// Log processed values
error_log("Checkout processed values - First: $first_name, Last: $last_name, Country: $country_name, Street: $Street_Address, City: $Town_City, Phone: $Phone, Email: $mail, Payment: $payment_method");

// Validate required fields
if (empty($first_name) || empty($last_name) || empty($country_name) || empty($Street_Address) ||
    empty($Town_City) || empty($Phone) || empty($mail)) {
    error_log("Checkout validation failed - missing required fields");
    header("Location: checkout.html?error=1");
    exit();
}

if (empty($payment_method)) {
    error_log("Checkout validation failed - payment method missing");
    header("Location: checkout.html?error=1&msg=" . urlencode("Payment method is required"));
    exit();
}

if (!$terms_accepted) {
    error_log("Checkout validation failed - terms not accepted");
    header("Location: checkout.html?error=1&msg=" . urlencode("Please accept the terms and conditions"));
    exit();
}

$payment_meta = [
    'notes' => $payment_notes,
];

switch ($payment_method) {
    case 'Direct Bank Transfer':
        if (empty($bank_account_name) || empty($bank_reference)) {
            header("Location: checkout.html?error=1&msg=" . urlencode("Bank transfer details are required"));
            exit();
        }
        $payment_meta['account_name'] = $bank_account_name;
        $payment_meta['reference'] = $bank_reference;
        break;
    case 'Check Payment':
        if (empty($check_holder) || empty($check_number)) {
            header("Location: checkout.html?error=1&msg=" . urlencode("Check details are required"));
            exit();
        }
        $payment_meta['check_holder'] = $check_holder;
        $payment_meta['check_number'] = $check_number;
        break;
    case 'Paypal':
        if (empty($paypal_email) || !filter_var($paypal_email, FILTER_VALIDATE_EMAIL)) {
            header("Location: checkout.html?error=1&msg=" . urlencode("Valid PayPal email is required"));
            exit();
        }
        $payment_meta['paypal_email'] = $paypal_email;
        break;
    case 'UPI':
        if (empty($upi_id)) {
            header("Location: checkout.html?error=1&msg=" . urlencode("UPI ID is required"));
            exit();
        }
        $payment_meta['upi_id'] = $upi_id;
        break;
    default:
        // No extra validation
        break;
}

// Create checkout table if it doesn't exist
$check_table = $conn->query("SHOW TABLES LIKE 'checkout'");
if ($check_table && $check_table->num_rows == 0) {
    // Table doesn't exist, create it
    $create_table_sql = "CREATE TABLE `checkout` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `first_name` VARCHAR(255) NOT NULL,
        `last_name` VARCHAR(255) NOT NULL,
        `country_name` VARCHAR(100) NOT NULL,
        `Street_Address` VARCHAR(255) NOT NULL,
        `Town_City` VARCHAR(100) NOT NULL,
        `Phone` VARCHAR(20) NOT NULL,
        `mail` VARCHAR(255) NOT NULL,
        `payment_method` VARCHAR(50) NOT NULL,
        `payment_status` VARCHAR(40) NOT NULL DEFAULT 'Pending',
        `payment_reference` VARCHAR(64) DEFAULT NULL,
        `payment_metadata` TEXT NULL,
        `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `delivery` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `terms_accepted` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($conn->query($create_table_sql) === FALSE) {
        $error_msg = "Error creating table: " . $conn->error;
        error_log("Checkout " . $error_msg);
        header("Location: checkout.html?error=db&msg=" . urlencode($error_msg));
        exit();
    }
    error_log("Checkout table created successfully");
}

if (!ensure_checkout_columns($conn)) {
    header("Location: checkout.html?error=db&msg=" . urlencode("Could not update checkout table structure"));
    exit();
}

$paymentResult = process_payment($payment_method, $total, $payment_meta);

if ($paymentResult['status'] === 'Failed') {
    header("Location: checkout.html?error=1&msg=" . urlencode($paymentResult['message']));
    exit();
}

$payment_metadata = json_encode($payment_meta, JSON_UNESCAPED_UNICODE);
if ($payment_metadata === false) {
    $payment_metadata = '{}';
}

// Prepare and execute insert statement
$stmt = $conn->prepare("INSERT INTO checkout (first_name, last_name, country_name, Street_Address, Town_City, Phone, mail, payment_method, payment_status, payment_reference, payment_metadata, subtotal, delivery, discount, total, terms_accepted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if ($stmt === false) {
    // Error in prepare statement
    $error_msg = "Prepare failed: " . $conn->error;
    error_log("Checkout " . $error_msg);
    header("Location: checkout.html?error=db&msg=" . urlencode($error_msg));
    exit();
}

$stmt->bind_param(
    "sssssssssssddddi",
    $first_name,
    $last_name,
    $country_name,
    $Street_Address,
    $Town_City,
    $Phone,
    $mail,
    $payment_method,
    $paymentResult['status'],
    $paymentResult['reference'],
    $payment_metadata,
    $subtotal,
    $delivery,
    $discount,
    $total,
    $terms_accepted
);

if ($stmt->execute()) {
    // Success - get the inserted ID
    $checkout_id = $conn->insert_id;
    error_log("Checkout success - Inserted ID: $checkout_id - Payment Ref: " . $paymentResult['reference']);
    
    $stmt->close();
    $conn->close();
    header("Location: thanks.html?checkout_id=" . $checkout_id . "&payment_ref=" . urlencode($paymentResult['reference']) . "&success=1");
    exit();
} else {
    // Error - redirect back with error message
    $error_msg = "Execute failed: " . $stmt->error;
    error_log("Checkout " . $error_msg);
    $stmt->close();
    $conn->close();
    header("Location: checkout.html?error=db&msg=" . urlencode($error_msg));
    exit();
}
?>
