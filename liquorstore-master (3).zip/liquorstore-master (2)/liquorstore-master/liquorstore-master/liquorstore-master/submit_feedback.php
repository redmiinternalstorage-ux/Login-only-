<?php
// Database connection
$servername = "localhost";
$username = "root";   // default XAMPP username
$password = "";       // default XAMPP password
$dbname = "liquorstore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form values and sanitize
$full_name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email_address = isset($_POST['email']) ? trim($_POST['email']) : '';
$subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

// Validate required fields
if (empty($full_name) || empty($email_address) || empty($subject) || empty($message)) {
    header("Location: contact.html?error=1");
    exit();
}

// Create feedback table if it doesn't exist
$create_table_sql = "CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email_address VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($create_table_sql) === FALSE) {
    error_log("Error creating table: " . $conn->error);
    header("Location: contact.html?error=1");
    exit();
}

// Prepare and execute insert statement
$stmt = $conn->prepare("INSERT INTO feedback (full_name, email_address, subject, message) VALUES (?, ?, ?, ?)");

if ($stmt === false) {
    // Error in prepare statement
    error_log("Prepare failed: " . $conn->error);
    header("Location: contact.html?error=1");
    exit();
}

$stmt->bind_param("ssss", $full_name, $email_address, $subject, $message);

if ($stmt->execute()) {
    // Success - redirect back to contact page with success message
    $stmt->close();
    $conn->close();
    header("Location: contact.html?success=1");
    exit();
} else {
    // Error - redirect back with error message
    error_log("Execute failed: " . $stmt->error);
    $stmt->close();
    $conn->close();
    header("Location: contact.html?error=1");
    exit();
}
?>

