<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";   // default XAMPP username
$password = "";       // default XAMPP password
$dbname = "liquorstore";

// Create connection without specifying database first
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    header("Location: userform.html?error=db&msg=" . urlencode("Connection failed: " . $conn->connect_error));
    exit();
}

// Create database if it doesn't exist
$create_db_sql = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($conn->query($create_db_sql) === FALSE) {
    header("Location: userform.html?error=db&msg=" . urlencode("Error creating database: " . $conn->error));
    exit();
}

// Select the database
if (!$conn->select_db($dbname)) {
    header("Location: userform.html?error=db&msg=" . urlencode("Error selecting database: " . $conn->error));
    exit();
}

// Get form values and sanitize
$your_name = isset($_POST['your_name']) ? trim($_POST['your_name']) : '';
$mobile_no = isset($_POST['mobile_no']) ? trim($_POST['mobile_no']) : '';
$email_id = isset($_POST['email_id']) ? trim($_POST['email_id']) : '';
$aadhar_no = isset($_POST['Aadhar_no']) ? trim($_POST['Aadhar_no']) : '';
$age = isset($_POST['Age']) ? intval(trim($_POST['Age'])) : 0;
$state = isset($_POST['State']) ? trim($_POST['State']) : '';
$address = isset($_POST['Address']) ? trim($_POST['Address']) : '';

// Validate required fields
if (empty($your_name) || empty($mobile_no) || empty($email_id) || empty($aadhar_no) || $age == 0 || empty($state) || empty($address)) {
    header("Location: userform.html?error=1");
    exit();
}

// Validate age (must be 19 or above)
if ($age < 19) {
    header("Location: userform.html?error=age");
    exit();
}

// Create users table if it doesn't exist
$create_table_sql = "CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `your_name` VARCHAR(255) NOT NULL,
    `mobile_no` VARCHAR(20) NOT NULL,
    `email_id` VARCHAR(255) NOT NULL,
    `Aadhar_no` VARCHAR(20) NOT NULL,
    `Age` INT NOT NULL,
    `State` VARCHAR(100) NOT NULL,
    `Address` TEXT NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_email` (`email_id`),
    UNIQUE KEY `unique_mobile` (`mobile_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_table_sql) === FALSE) {
    error_log("Error creating table: " . $conn->error);
    header("Location: userform.html?error=1");
    exit();
}

// Check if email or mobile already exists
$check_stmt = $conn->prepare("SELECT id FROM users WHERE email_id = ? OR mobile_no = ?");
if ($check_stmt === false) {
    error_log("Prepare failed for check: " . $conn->error);
    header("Location: userform.html?error=1");
    exit();
}

$check_stmt->bind_param("ss", $email_id, $mobile_no);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows > 0) {
    // User already exists
    $check_stmt->close();
    $conn->close();
    header("Location: userform.html?error=exists");
    exit();
}
$check_stmt->close();

// Prepare and execute insert statement
$stmt = $conn->prepare("INSERT INTO users (your_name, mobile_no, email_id, Aadhar_no, Age, State, Address) VALUES (?, ?, ?, ?, ?, ?, ?)");

if ($stmt === false) {
    // Error in prepare statement
    $error_msg = "Prepare failed: " . $conn->error;
    error_log($error_msg);
    header("Location: userform.html?error=db&msg=" . urlencode($error_msg));
    exit();
}

// Bind parameters - note: Age is integer (i), others are strings (s)
$stmt->bind_param("ssssiss", $your_name, $mobile_no, $email_id, $aadhar_no, $age, $state, $address);

if ($stmt->execute()) {
    // Success - get the inserted ID
    $inserted_id = $conn->insert_id;
    
    // Set session variables for logged in user
    $_SESSION['user_logged_in'] = true;
    $_SESSION['user_id'] = $inserted_id;
    $_SESSION['user_name'] = $your_name;
    $_SESSION['user_email'] = $email_id;
    
    $stmt->close();
    $conn->close();
    
    // Redirect to homepage with success message
    header("Location: index.php?registration=success&name=" . urlencode($your_name));
    exit();
} else {
    // Error - redirect back with error message
    $error_msg = "Execute failed: " . $stmt->error;
    $stmt->close();
    $conn->close();
    // Show more detailed error for debugging
    header("Location: userform.html?error=db&msg=" . urlencode($error_msg));
    exit();
}
?>
