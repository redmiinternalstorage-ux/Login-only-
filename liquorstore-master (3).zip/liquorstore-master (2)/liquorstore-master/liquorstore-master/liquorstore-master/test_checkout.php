<?php
// Test Checkout Insert Script
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

echo "<!DOCTYPE html>
<html>
<head>
    <title>Test Checkout</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        .success { color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; }
        .error { color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; }
        .info { color: blue; padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
    </style>
</head>
<body>
<div class='container'>
<h1>Test Checkout Insert</h1>";

// Create connection
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div></div></body></html>");
}

echo "<div class='success'>✓ Connected to MySQL</div>";

// Select database
$conn->select_db($dbname);

// Drop and create checkout table
$drop_table = "DROP TABLE IF EXISTS `checkout`";
$conn->query($drop_table);

$create_table_sql = "CREATE TABLE `checkout` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `first_name` VARCHAR(255) NOT NULL,
    `last_name` VARCHAR(255) NOT NULL,
    `country_name` VARCHAR(100) NOT NULL,
    `Street_Address` VARCHAR(255) NOT NULL,
    `Town_City` VARCHAR(100) NOT NULL,
    `Phone` VARCHAR(20) NOT NULL,
    `mail` VARCHAR(255) NOT NULL,
    `payment_method` VARCHAR(50) NOT NULL,
    `payment_status` VARCHAR(40) NOT NULL DEFAULT 'Pending',
    `payment_reference` VARCHAR(64) DEFAULT NULL,
    `payment_metadata` TEXT NULL,
    `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `delivery` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `terms_accepted` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($create_table_sql) === TRUE) {
    echo "<div class='success'>✓ Checkout table created</div>";
} else {
    echo "<div class='error'>✗ Error creating table: " . $conn->error . "</div>";
    $conn->close();
    echo "</div></body></html>";
    exit();
}

// Test insert
$test_first = "John";
$test_last = "Doe";
$test_country = "Delhi";
$test_street = "123 Test Street";
$test_city = "New Delhi";
$test_phone = "9876543210";
$test_mail = "test@example.com";
$test_payment_method = "Direct Bank Transfer";
$test_payment_status = "Awaiting Verification";
$test_payment_reference = "BNK-" . date('YmdHis');
$test_payment_metadata = json_encode([
    'account_name' => 'John Doe',
    'reference' => 'UTRTEST123',
    'notes' => 'Quick verification'
]);
$test_subtotal = 40.00;
$test_delivery = 0.00;
$test_discount = 5.00;
$test_total = 35.00;
$test_terms = 1;

$stmt = $conn->prepare("INSERT INTO checkout (first_name, last_name, country_name, Street_Address, Town_City, Phone, mail, payment_method, payment_status, payment_reference, payment_metadata, subtotal, delivery, discount, total, terms_accepted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if ($stmt) {
    $stmt->bind_param(
        "sssssssssssddddi",
        $test_first,
        $test_last,
        $test_country,
        $test_street,
        $test_city,
        $test_phone,
        $test_mail,
        $test_payment_method,
        $test_payment_status,
        $test_payment_reference,
        $test_payment_metadata,
        $test_subtotal,
        $test_delivery,
        $test_discount,
        $test_total,
        $test_terms
    );
    
    if ($stmt->execute()) {
        $id = $conn->insert_id;
        echo "<div class='success'>✓ Test insert successful! ID: $id</div>";
    } else {
        echo "<div class='error'>✗ Insert failed: " . $stmt->error . "</div>";
    }
    $stmt->close();
} else {
    echo "<div class='error'>✗ Prepare failed: " . $conn->error . "</div>";
}

// Show all records
echo "<h2>All Checkout Records:</h2>";
$result = $conn->query("SELECT * FROM checkout ORDER BY id DESC");
if ($result && $result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Country</th><th>Town/City</th><th>Phone</th><th>Email</th><th>Payment Method</th><th>Status</th><th>Total</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['country_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Town_City']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Phone']) . "</td>";
        echo "<td>" . htmlspecialchars($row['mail']) . "</td>";
        echo "<td>" . htmlspecialchars($row['payment_method']) . "</td>";
        echo "<td>" . htmlspecialchars($row['payment_status']) . "</td>";
        echo "<td>$" . htmlspecialchars($row['total']) . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='info'>No records found</div>";
}

$conn->close();

echo "<p><a href='checkout.html'>Go to Checkout Form</a></p>";
echo "</div></body></html>";
?>




