<?php
// Test Checkout Insert - Direct Test
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

echo "<!DOCTYPE html>
<html>
<head>
    <title>Test Checkout Insert</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        .success { color: green; padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; }
        .error { color: red; padding: 15px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; }
        .info { color: blue; padding: 15px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
        .btn { display: inline-block; padding: 12px 24px; margin: 10px 5px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
    </style>
</head>
<body>
<div class='container'>
<h1>Test Checkout Insert</h1>";

// Connect
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div></div></body></html>");
}

$conn->select_db($dbname);

// Ensure table exists
$check_table = $conn->query("SHOW TABLES LIKE 'checkout'");
if (!$check_table || $check_table->num_rows == 0) {
    echo "<div class='error'>Table doesn't exist. Creating it...</div>";
    
    $create_table_sql = "CREATE TABLE `checkout` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `first_name` VARCHAR(255) NOT NULL,
        `last_name` VARCHAR(255) NOT NULL,
        `country_name` VARCHAR(100) NOT NULL,
        `Street_Address` VARCHAR(255) NOT NULL,
        `Town_City` VARCHAR(100) NOT NULL,
        `Phone` VARCHAR(20) NOT NULL,
        `mail` VARCHAR(255) NOT NULL,
        `payment_method` VARCHAR(50) NOT NULL,
        `payment_status` VARCHAR(40) NOT NULL DEFAULT 'Pending',
        `payment_reference` VARCHAR(64) DEFAULT NULL,
        `payment_metadata` TEXT NULL,
        `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `delivery` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `discount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        `terms_accepted` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if ($conn->query($create_table_sql)) {
        echo "<div class='success'>✓ Table created</div>";
    } else {
        die("<div class='error'>Error creating table: " . $conn->error . "</div></div></body></html>");
    }
}

// Test insert with actual values
echo "<h2>Testing Insert:</h2>";
$test_first = "John";
$test_last = "Smith";
$test_country = "Delhi";
$test_street = "456 Main Street";
$test_city = "New Delhi";
$test_phone = "9876543210";
$test_mail = "john.smith" . time() . "@example.com";

echo "<div class='info'>Inserting: $test_first $test_last, $test_country, $test_street, $test_city, $test_phone, $test_mail</div>";

$test_payment_method = "Paypal";
$test_payment_status = "Authorized";
$test_payment_reference = "PAY-" . date('YmdHis');
$test_payment_metadata = json_encode([
    'paypal_email' => $test_mail,
    'notes' => 'Direct test run'
]);
$test_subtotal = 22.50;
$test_delivery = 0.00;
$test_discount = 2.50;
$test_total = 20.00;
$test_terms = 1;

$stmt = $conn->prepare("INSERT INTO checkout (first_name, last_name, country_name, Street_Address, Town_City, Phone, mail, payment_method, payment_status, payment_reference, payment_metadata, subtotal, delivery, discount, total, terms_accepted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if ($stmt) {
    $stmt->bind_param(
        "sssssssssssddddi",
        $test_first,
        $test_last,
        $test_country,
        $test_street,
        $test_city,
        $test_phone,
        $test_mail,
        $test_payment_method,
        $test_payment_status,
        $test_payment_reference,
        $test_payment_metadata,
        $test_subtotal,
        $test_delivery,
        $test_discount,
        $test_total,
        $test_terms
    );
    
    if ($stmt->execute()) {
        $id = $conn->insert_id;
        echo "<div class='success'>✓ INSERT SUCCESSFUL! ID: $id</div>";
        
        // Verify by reading it back
        $result = $conn->query("SELECT * FROM checkout WHERE id = $id");
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "<div class='success'>✓ Verified: Record exists in database</div>";
            echo "<div class='info'>";
            echo "ID: " . $row['id'] . "<br>";
            echo "Name: " . $row['first_name'] . " " . $row['last_name'] . "<br>";
            echo "Country: " . $row['country_name'] . "<br>";
            echo "Address: " . $row['Street_Address'] . "<br>";
            echo "City: " . $row['Town_City'] . "<br>";
            echo "Phone: " . $row['Phone'] . "<br>";
            echo "Email: " . $row['mail'] . "<br>";
            echo "Payment Method: " . $row['payment_method'] . "<br>";
            echo "Payment Status: " . $row['payment_status'] . "<br>";
            echo "Payment Reference: " . $row['payment_reference'] . "<br>";
            echo "Total: $" . $row['total'] . "<br>";
            echo "Created: " . $row['created_at'];
            echo "</div>";
        }
    } else {
        echo "<div class='error'>✗ INSERT FAILED: " . $stmt->error . "</div>";
    }
    $stmt->close();
} else {
    echo "<div class='error'>✗ PREPARE FAILED: " . $conn->error . "</div>";
}

// Show all records
echo "<h2>All Records in Checkout Table:</h2>";
$result = $conn->query("SELECT * FROM checkout ORDER BY id DESC");
if ($result && $result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>ID</th><th>Name</th><th>Country</th><th>Town/City</th><th>Phone</th><th>Email</th><th>Payment</th><th>Status</th><th>Total</th><th>Created</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['country_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Town_City']) . "</td>";
        echo "<td>" . htmlspecialchars($row['Phone']) . "</td>";
        echo "<td>" . htmlspecialchars($row['mail']) . "</td>";
        echo "<td>" . htmlspecialchars($row['payment_method']) . "</td>";
        echo "<td>" . htmlspecialchars($row['payment_status']) . "</td>";
        echo "<td>$" . htmlspecialchars($row['total']) . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<div class='info'>No records found</div>";
}

$conn->close();

echo "<p><a href='checkout.html' class='btn'>Go to Checkout Form</a> ";
echo "<a href='view_checkout_data.php' class='btn'>View All Data</a></p>";
echo "</div></body></html>";
?>




