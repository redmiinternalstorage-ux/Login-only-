<?php
// Simple test to verify database insertion works
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

// Create connection
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$create_db_sql = "CREATE DATABASE IF NOT EXISTS " . $dbname;
$conn->query($create_db_sql);
$conn->select_db($dbname);

// Create users table if it doesn't exist
$create_table_sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    your_name VARCHAR(255) NOT NULL,
    mobile_no VARCHAR(20) NOT NULL,
    email_id VARCHAR(255) NOT NULL,
    Aadhar_no VARCHAR(20) NOT NULL,
    Age INT NOT NULL,
    State VARCHAR(100) NOT NULL,
    Address TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$conn->query($create_table_sql);

// Test insert
$test_name = "Test User";
$test_mobile = "1234567890";
$test_email = "test@example.com";
$test_aadhar = "123456789012";
$test_age = 25;
$test_state = "Delhi";
$test_address = "Test Address";

$stmt = $conn->prepare("INSERT INTO users (your_name, mobile_no, email_id, Aadhar_no, Age, State, Address) VALUES (?, ?, ?, ?, ?, ?, ?)");

if ($stmt) {
    $stmt->bind_param("ssssiss", $test_name, $test_mobile, $test_email, $test_aadhar, $test_age, $test_state, $test_address);
    
    if ($stmt->execute()) {
        echo "<h2 style='color: green;'>SUCCESS! Test data inserted successfully!</h2>";
        echo "<p>Inserted ID: " . $conn->insert_id . "</p>";
    } else {
        echo "<h2 style='color: red;'>ERROR: " . $stmt->error . "</h2>";
    }
    $stmt->close();
} else {
    echo "<h2 style='color: red;'>ERROR preparing statement: " . $conn->error . "</h2>";
}

// Show all users
echo "<h3>All users in database:</h3>";
$result = $conn->query("SELECT * FROM users");
if ($result && $result->num_rows > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Name</th><th>Mobile</th><th>Email</th><th>Age</th><th>State</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['your_name'] . "</td>";
        echo "<td>" . $row['mobile_no'] . "</td>";
        echo "<td>" . $row['email_id'] . "</td>";
        echo "<td>" . $row['Age'] . "</td>";
        echo "<td>" . $row['State'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No users found in database.</p>";
}

$conn->close();
?>




