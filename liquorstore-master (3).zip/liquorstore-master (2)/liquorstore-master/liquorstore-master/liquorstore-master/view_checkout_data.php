<?php
// View Checkout Database Data
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "liquorstore";

echo "<!DOCTYPE html>
<html>
<head>
    <title>View Checkout Data</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; margin: 10px 0; border-radius: 5px; }
        .error { color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; margin: 10px 0; border-radius: 5px; }
        .info { color: blue; padding: 10px; background: #d1ecf1; border: 1px solid #bee5eb; margin: 10px 0; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; position: sticky; top: 0; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        tr:hover { background-color: #e8f5e9; }
        .btn { display: inline-block; padding: 10px 20px; margin: 10px 5px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
        .btn:hover { background: #45a049; }
        .btn-danger { background: #f44336; }
        .btn-danger:hover { background: #da190b; }
        .stats { display: flex; gap: 20px; margin: 20px 0; }
        .stat-box { flex: 1; padding: 15px; background: #e3f2fd; border-radius: 5px; text-align: center; }
        .stat-box h3 { margin: 0; color: #1976d2; }
        .stat-box p { margin: 5px 0 0 0; font-size: 24px; font-weight: bold; color: #0d47a1; }
    </style>
</head>
<body>
<div class='container'>
<h1>Checkout Database Records</h1>";

// Create connection
$conn = new mysqli($servername, $username, $password);

if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div></div></body></html>");
}

// Select database
if (!$conn->select_db($dbname)) {
    die("<div class='error'>Database '$dbname' not found. Please run setup_database.php first.</div></div></body></html>");
}

echo "<div class='success'>✓ Connected to database '$dbname'</div>";

// Check if checkout table exists
$result = $conn->query("SHOW TABLES LIKE 'checkout'");
if ($result && $result->num_rows > 0) {
    echo "<div class='success'>✓ Checkout table exists</div>";
    
    // Get record count
    $count_result = $conn->query("SELECT COUNT(*) as count FROM `checkout`");
    $count_row = $count_result->fetch_assoc();
    $count = $count_row['count'];
    
    echo "<div class='stats'>";
    echo "<div class='stat-box'><h3>Total Records</h3><p>$count</p></div>";
    
    // Get today's count
    $today_result = $conn->query("SELECT COUNT(*) as count FROM `checkout` WHERE DATE(created_at) = CURDATE()");
    $today_row = $today_result->fetch_assoc();
    $today_count = $today_row['count'];
    echo "<div class='stat-box'><h3>Today's Orders</h3><p>$today_count</p></div>";
    echo "</div>";
    
    // Get all records
    $result = $conn->query("SELECT * FROM `checkout` ORDER BY `id` DESC");
    
    if ($result && $result->num_rows > 0) {
        echo "<h2>All Checkout Records:</h2>";
        echo "<table>";
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Customer</th>";
        echo "<th>Country</th>";
        echo "<th>Town/City</th>";
        echo "<th>Phone</th>";
        echo "<th>Email</th>";
        echo "<th>Payment Method</th>";
        echo "<th>Status</th>";
        echo "<th>Subtotal</th>";
        echo "<th>Discount</th>";
        echo "<th>Total</th>";
        echo "<th>Terms</th>";
        echo "<th>Created At</th>";
        echo "</tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['country_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['Town_City']) . "</td>";
            echo "<td>" . htmlspecialchars($row['Phone']) . "</td>";
            echo "<td>" . htmlspecialchars($row['mail']) . "</td>";
            echo "<td>" . htmlspecialchars($row['payment_method']) . "</td>";
            echo "<td>" . htmlspecialchars($row['payment_status']) . "</td>";
            echo "<td>$" . htmlspecialchars($row['subtotal']) . "</td>";
            echo "<td>$" . htmlspecialchars($row['discount']) . "</td>";
            echo "<td>$" . htmlspecialchars($row['total']) . "</td>";
            echo "<td>" . ($row['terms_accepted'] ? 'Yes' : 'No') . "</td>";
            echo "<td>" . $row['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div class='info'>No records found in checkout table. Try submitting the checkout form.</div>";
    }
    
    // Show table structure
    echo "<h2>Table Structure:</h2>";
    $result = $conn->query("DESCRIBE `checkout`");
    if ($result) {
        echo "<table>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td><strong>" . $row['Field'] . "</strong></td>";
            echo "<td>" . $row['Type'] . "</td>";
            echo "<td>" . $row['Null'] . "</td>";
            echo "<td>" . $row['Key'] . "</td>";
            echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
            echo "<td>" . $row['Extra'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} else {
    echo "<div class='error'>✗ Checkout table does NOT exist</div>";
    echo "<div class='info'>Please run <a href='setup_checkout_table.php'>setup_checkout_table.php</a> to create it.</div>";
}

$conn->close();

echo "<div style='margin-top: 30px;'>";
echo "<a href='checkout.html' class='btn'>Go to Checkout Form</a> ";
echo "<a href='setup_checkout_table.php' class='btn'>Setup Checkout Table</a> ";
echo "<a href='test_checkout.php' class='btn'>Test Checkout</a> ";
echo "<a href='check_database.php' class='btn'>Check All Databases</a>";
echo "</div>";

echo "</div></body></html>";
?>




